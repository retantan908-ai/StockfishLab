@echo off
setlocal
set VERSION=8.13
if defined GRADLE_USER_HOME (set BASE=%GRADLE_USER_HOME%\stockfishlab-bootstrap) else (set BASE=%USERPROFILE%\.gradle\stockfishlab-bootstrap)
set GRADLE_HOME=%BASE%\gradle-%VERSION%
if exist "%GRADLE_HOME%\bin\gradle.bat" goto run
if not exist "%BASE%" mkdir "%BASE%"
echo Downloading Gradle %VERSION%...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%BASE%\gradle-%VERSION%-bin.zip'; Expand-Archive -LiteralPath '%BASE%\gradle-%VERSION%-bin.zip' -DestinationPath '%BASE%' -Force"
if errorlevel 1 exit /b 1
:run
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
