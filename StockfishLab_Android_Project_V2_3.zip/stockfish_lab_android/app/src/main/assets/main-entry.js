import { Chess } from './vendor/chess.js';
(() => {
  'use strict';
  const START_FEN='rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  const GLYPH={wk:'♔',wq:'♕',wr:'♖',wb:'♗',wn:'♘',wp:'♙',bk:'♚',bq:'♛',br:'♜',bb:'♝',bn:'♞',bp:'♟'};
  const $=id=>document.getElementById(id);
  let game=new Chess(), orientation='w', selected=null, legalTargets=[], pendingPromotion=null;
  let states=[{fen:game.fen(),sans:[],last:null}], stateIndex=0;
  let worker=null, engineReady=false, booting=true, searchRunning=false, waitingReady=false, stopRequested=false, engineBootTimer=null;
  let pendingJob=null, currentJob=null, jobCounter=0, bestMoveUci=null, bestSeen={}, latestDepth=0, startedAt=0;

  function setStatus(message,good=false){$('statusText').textContent=message;$('status').classList.toggle('ready',!!good);}
  function resetResults(){bestMoveUci=null;bestSeen={};latestDepth=0;$('bestMove').textContent='—';$('evaluation').textContent='—';$('depthReached').textContent='—';$('elapsed').textContent='—';$('variations').innerHTML='<div class="empty">Menunggu hasil analisis...</div>';$('applyBest').style.display='none';paintBestSquares();}
  function paintBestSquares(){const cells=$('board').querySelectorAll('.sq');cells.forEach(c=>c.classList.remove('best-from','best-to'));if(!bestMoveUci)return;const from=bestMoveUci.slice(0,2),to=bestMoveUci.slice(2,4);cells.forEach(c=>{if(c.dataset.square===from)c.classList.add('best-from');if(c.dataset.square===to)c.classList.add('best-to');});}
  function currentState(){return states[stateIndex];}
  function setFenBox(){ $('fen').value=game.fen(); }
  function statusForPosition(){
    if(game.isCheckmate())return 'Skakmat · '+(game.turn()==='w'?'Hitam':'Putih')+' menang.';
    if(game.isStalemate())return 'Remis · stalemate.';
    if(game.isDraw())return 'Posisi remis.';
    return 'Giliran '+(game.turn()==='w'?'putih':'hitam')+(game.isCheck()?' · skak!':'')+'.';
  }
  function drawBoard(){
    const board=$('board');board.innerHTML='';
    const files=orientation==='w'?'abcdefgh'.split(''):'hgfedcba'.split('');
    const ranks=orientation==='w'?[8,7,6,5,4,3,2,1]:[1,2,3,4,5,6,7,8];
    const state=currentState();
    const destinations=new Set(legalTargets.map(m=>m.to));
    const last=state.last;
    const best=bestMoveUci?{from:bestMoveUci.slice(0,2),to:bestMoveUci.slice(2,4)}:null;
    for(let ri=0;ri<8;ri++)for(let fi=0;fi<8;fi++){
      const file=files[fi],rank=ranks[ri],square=file+rank,piece=game.get(square);
      const cell=document.createElement('div');cell.className='sq '+(((('abcdefgh'.indexOf(file)+rank)%2)===0)?'light':'dark');cell.dataset.square=square;
      if(square===selected)cell.classList.add('selected');
      if(last&&(square===last.from||square===last.to))cell.classList.add('last');
      if(best&&(square===best.from||square===best.to))cell.classList.add(square===best.from?'best-from':'best-to');
      if(piece){const span=document.createElement('span');span.className='piece '+(piece.color==='w'?'white':'black');span.textContent=GLYPH[piece.color+piece.type];cell.appendChild(span);cell.draggable=piece.color===game.turn();}
      if(fi===0){const n=document.createElement('span');n.className='coord rank';n.textContent=rank;cell.appendChild(n);}
      if(ri===7){const f=document.createElement('span');f.className='coord file';f.textContent=file;cell.appendChild(f);}
      if(destinations.has(square)){const dot=document.createElement('span');dot.className='target'+(piece?' capture':'');cell.appendChild(dot);}
      board.appendChild(cell);
    }
    $('turnLabel').textContent=statusForPosition()+' Sentuh bidak, lalu kotak tujuan; atau seret bidak.';
    $('undo').disabled=stateIndex===0;$('redo').disabled=stateIndex>=states.length-1;
    renderHistory();setFenBox();
  }
  function renderHistory(){
    const holder=$('moveHistory'),sans=currentState().sans;holder.innerHTML='';
    if(!sans.length){holder.innerHTML='<div class="empty" style="width:100%">Belum ada langkah.</div>';return;}
    for(let i=0;i<sans.length;i+=2){const n=document.createElement('span');n.className='move-pill';n.textContent=(Math.floor(i/2)+1)+'. '+sans[i]+(sans[i+1]?'  '+sans[i+1]:'');holder.appendChild(n);}
  }
  function selectSquare(square){
    if(pendingPromotion)return;
    const piece=game.get(square);
    if(selected){
      const candidates=legalTargets.filter(m=>m.to===square);
      if(candidates.length){
        if(candidates.length>1||candidates[0].promotion){showPromotion(candidates);return;}
        playMove({from:selected,to:square});return;
      }
    }
    if(piece&&piece.color===game.turn()){
      selected=square;legalTargets=game.moves({square,verbose:true});drawBoard();
    }else{selected=null;legalTargets=[];drawBoard();}
  }
  function playMove(move){
    try{
      const made=game.move(move);
      if(!made){setStatus('Langkah tidak legal. Pilih kotak yang ditandai.',false);return;}
      const sans=currentState().sans.concat(made.san);
      states=states.slice(0,stateIndex+1);states.push({fen:game.fen(),sans,last:{from:made.from,to:made.to}});stateIndex++;
      selected=null;legalTargets=[];pendingPromotion=null;$('promotion').classList.add('hide');resetResults();drawBoard();
      if($('autoAnalyze').checked)requestAnalysis();else setStatus('Langkah tersimpan. Tekan Analisis Posisi untuk mencari langkah terbaik.',true);
    }catch(e){setStatus('Tidak bisa memainkan langkah: '+e.message,false);}
  }
  function showPromotion(candidates){
    pendingPromotion=candidates;$('promotionChoices').innerHTML='';
    const map={q:'♕',r:'♖',b:'♗',n:'♘'};
    for(const m of candidates){const b=document.createElement('button');b.textContent=map[m.promotion]||m.promotion;b.setAttribute('aria-label',m.promotion);b.addEventListener('click',()=>{const chosen=pendingPromotion.find(x=>x.promotion===m.promotion);if(chosen)playMove({from:chosen.from,to:chosen.to,promotion:chosen.promotion});});$('promotionChoices').appendChild(b);}
    $('promotion').classList.remove('hide');
  }
  function saveNewPosition(){states=states.slice(0,stateIndex+1);states.push({fen:game.fen(),sans:[],last:null});stateIndex=states.length-1;selected=null;legalTargets=[];resetResults();drawBoard();}
  function undo(){if(stateIndex<=0)return;stateIndex--;game.load(states[stateIndex].fen);selected=null;legalTargets=[];resetResults();drawBoard();if($('autoAnalyze').checked)requestAnalysis();}
  function redo(){if(stateIndex>=states.length-1)return;stateIndex++;game.load(states[stateIndex].fen);selected=null;legalTargets=[];resetResults();drawBoard();if($('autoAnalyze').checked)requestAnalysis();}
  function resetGame(){game=new Chess();states=[{fen:game.fen(),sans:[],last:null}];stateIndex=0;selected=null;legalTargets=[];pendingPromotion=null;$('promotion').classList.add('hide');resetResults();drawBoard();requestAnalysis();}
  function loadFen(){try{const next=new Chess($('fen').value.trim());game=next;states=[{fen:game.fen(),sans:[],last:null}];stateIndex=0;selected=null;legalTargets=[];resetResults();drawBoard();requestAnalysis();}catch(e){setStatus('FEN tidak valid: '+e.message,false);}}

  function formatUci(uci){if(!uci||uci==='(none)'||uci==='0000')return '—';return uci.slice(0,2).toUpperCase()+' → '+uci.slice(2,4).toUpperCase()+(uci.length>4?' = '+uci[4].toUpperCase():'');}
  function whiteEval(kind,value,turn){const n=Number(value)*(turn==='w'?1:-1);if(kind==='mate')return(n>0?'+':'')+'M'+n;return(n>0?'+':'')+(n/100).toFixed(2);}
  function pvToSan(fen,pv){try{const copy=new Chess(fen);const out=[];const uciMoves=pv.trim().split(/\s+/);for(const u of uciMoves){if(!/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(u))break;const m=copy.move({from:u.slice(0,2),to:u.slice(2,4),promotion:u[4]||'q'});if(!m)break;out.push(m.san);}return out.join(' ');}catch(e){return pv;}}
  function updateVariation(line,job){
    const depth=Number((line.match(/\bdepth (\d+)/)||[])[1]||0),multipv=Number((line.match(/\bmultipv (\d+)/)||[])[1]||1),score=line.match(/\bscore (cp|mate) (-?\d+)/),pv=line.match(/\bpv (.+)$/);
    if(!score||!pv)return;
    bestSeen[multipv]={depth,eval:whiteEval(score[1],score[2],job.turn),pv:pv[1].trim(),san:pvToSan(job.fen,pv[1]),first:pv[1].trim().split(/\s+/)[0]};
    latestDepth=Math.max(latestDepth,depth);$('depthReached').textContent=String(latestDepth);renderVariations(job);
  }
  function renderVariations(job){
    const keys=Object.keys(bestSeen).map(Number).sort((a,b)=>a-b);if(!keys.length)return;
    $('bestMove').textContent=formatUci(bestSeen[1]?.first);$('evaluation').textContent=bestSeen[1]?.eval||'—';$('variations').innerHTML='';
    keys.forEach(k=>{const v=bestSeen[k],item=document.createElement('div');item.className='variation';const rank=document.createElement('div');rank.className='rank';rank.textContent=k;const main=document.createElement('div');main.className='vmain';const ev=document.createElement('div');ev.className='veval';ev.textContent=v.eval+' · '+formatUci(v.first);const pv=document.createElement('div');pv.className='pv';pv.textContent=v.san||v.pv;main.append(ev,pv);item.append(rank,main);$('variations').appendChild(item);});
    if(bestSeen[1]?.first){bestMoveUci=bestSeen[1].first;$('applyBest').style.display='block';paintBestSquares();}
  }
  function stopEngine(){
    if(engineBootTimer){clearTimeout(engineBootTimer);engineBootTimer=null;}
    if(worker){try{worker.postMessage('stop');worker.terminate();}catch(e){}}
    worker=null;engineReady=false;searchRunning=false;waitingReady=false;stopRequested=false;
  }
  function failEngine(message){
    stopEngine();booting=true;
    setStatus(message+' Papan tetap bisa dimainkan; tekan Coba lagi untuk memuat engine ulang.',false);
    $('analyze').disabled=false;$('analyze').textContent='COBA LAGI MUAT ENGINE';
  }
  function initEngine(){
    if(worker||engineReady)return;
    try{
      if(!('Worker' in window)){failEngine('Browser ini tidak mendukung Web Worker.');return;}
      booting=true;
      setStatus('Memuat Stockfish lokal…',false);
      worker=new Worker(new URL('/engine/stockfish-19-lite-single.js', window.location.href), { type: 'classic' });
      worker.onerror=e=>failEngine('Engine lokal gagal dimuat'+(e&&e.message?': '+e.message:'.')+' Periksa folder /engine/ dan file WASM.');
      worker.onmessageerror=()=>failEngine('Pesan dari engine tidak dapat dibaca. Coba muat ulang engine.');
      worker.onmessage=e=>handleEngineMessage(String(e.data||'').trim());
      engineBootTimer=setTimeout(()=>{
        if(!engineReady)failEngine('Stockfish tidak merespons dalam 45 detik. Periksa file JS/WASM dan koneksi hosting.');
      },45000);
      worker.postMessage('uci');
    }catch(e){failEngine('Tidak dapat membuka engine: '+(e&&e.message?e.message:String(e)));}
  }
  function preparePendingJob(){
    if(!pendingJob||!engineReady||searchRunning||waitingReady)return;
    currentJob=pendingJob;pendingJob=null;bestSeen={};latestDepth=0;bestMoveUci=null;startedAt=Date.now();
    $('bestMove').textContent='Menghitung...';$('evaluation').textContent='—';$('depthReached').textContent='0';$('elapsed').textContent='0.0 dtk';$('variations').innerHTML='<div class="empty">Stockfish sedang menghitung...</div>';$('applyBest').style.display='none';
    worker.postMessage('setoption name MultiPV value '+currentJob.multipv);
    worker.postMessage('position fen '+currentJob.fen);
    waitingReady=true;worker.postMessage('isready');
    $('analyze').disabled=true;$('analyze').textContent='MENGANALISIS...';setStatus('Menyiapkan analisis posisi...',false);
  }
  function requestAnalysis(){
    const depth=Number($('depth').value),multipv=Number($('multipv').value);
    pendingJob={id:++jobCounter,fen:game.fen(),turn:game.turn(),depth,multipv};
    if(!engineReady){setStatus(worker?'Menunggu Stockfish siap…':'Mencoba memuat Stockfish lokal…',false);if(!worker)initEngine();return;}
    if(searchRunning){if(!stopRequested){stopRequested=true;worker.postMessage('stop');}setStatus('Menghentikan analisis posisi sebelumnya...',false);return;}
    if(waitingReady){setStatus('Memperbarui permintaan analisis...',false);return;}
    preparePendingJob();
  }
  function handleEngineMessage(line){
    if(!line)return;
    if(line==='uciok'){
      worker.postMessage('setoption name Threads value 1');worker.postMessage('setoption name Hash value 48');worker.postMessage('isready');return;
    }
    if(line==='readyok'){
      if(booting){booting=false;engineReady=true;if(engineBootTimer){clearTimeout(engineBootTimer);engineBootTimer=null;}setStatus('Stockfish siap · analisis otomatis aktif.',true);requestAnalysis();return;}
      if(waitingReady){
        waitingReady=false;
        if(pendingJob&&currentJob&&pendingJob.id!==currentJob.id){preparePendingJob();return;}
        if(!currentJob)return;
        searchRunning=true;stopRequested=false;worker.postMessage('go depth '+currentJob.depth);setStatus('Menganalisis posisi · target depth '+currentJob.depth+'.',true);return;
      }
      return;
    }
    if(line.startsWith('info ')&&currentJob&&!stopRequested){updateVariation(line,currentJob);$('elapsed').textContent=((Date.now()-startedAt)/1000).toFixed(1)+' dtk';return;}
    if(line.startsWith('bestmove')){
      searchRunning=false;
      if(stopRequested){stopRequested=false;if(pendingJob){preparePendingJob();return;}}
      const move=(line.match(/^bestmove\s+(\S+)/)||[])[1]||'(none)';
      if(!bestSeen[1]&&move!=='(none)'){$('bestMove').textContent=formatUci(move);bestMoveUci=move;$('applyBest').style.display='block';paintBestSquares();}
      $('elapsed').textContent=((Date.now()-startedAt)/1000).toFixed(1)+' dtk';$('analyze').disabled=false;$('analyze').textContent='ANALISIS ULANG';
      setStatus(move==='(none)'?'Tidak ada langkah legal pada posisi ini.':'Analisis selesai · langkah terbaik ditemukan.',true);
      if(pendingJob)preparePendingJob();return;
    }
    if(line.startsWith('info string')&&/error|invalid|critical/i.test(line)){setStatus(line,false);}
  }
  function applyBest(){
    if(!bestMoveUci||bestMoveUci==='(none)')return;
    const u=bestMoveUci;const move={from:u.slice(0,2),to:u.slice(2,4)};if(u.length>4)move.promotion=u[4];
    const preview=game.moves({verbose:true}).find(m=>m.from===move.from&&m.to===move.to&&(!move.promotion||m.promotion===move.promotion));
    if(!preview){setStatus('Langkah hasil analisis tidak cocok dengan posisi papan sekarang. Analisis ulang.',false);return;}
    playMove(move);
  }

  $('board').addEventListener('click',e=>{const cell=e.target.closest('.sq');if(cell)selectSquare(cell.dataset.square);});
  $('board').addEventListener('dragstart',e=>{const cell=e.target.closest('.sq');if(!cell||!cell.draggable){e.preventDefault();return;}selected=cell.dataset.square;legalTargets=game.moves({square:selected,verbose:true});e.dataTransfer.setData('text/plain',selected);});
  $('board').addEventListener('dragover',e=>{if(e.target.closest('.sq'))e.preventDefault();});
  $('board').addEventListener('drop',e=>{const cell=e.target.closest('.sq');if(!cell)return;e.preventDefault();const from=e.dataTransfer.getData('text/plain'),to=cell.dataset.square;const candidates=game.moves({square:from,verbose:true}).filter(m=>m.to===to);if(candidates.length>1||candidates[0]?.promotion)showPromotion(candidates);else if(candidates.length)playMove({from,to});else{selected=null;legalTargets=[];drawBoard();}});
  $('undo').addEventListener('click',undo);$('redo').addEventListener('click',redo);$('flip').addEventListener('click',()=>{$('side').value=orientation==='w'?'b':'w';orientation=$('side').value;drawBoard();});
  $('side').addEventListener('change',()=>{orientation=$('side').value;drawBoard();});$('newGame').addEventListener('click',resetGame);$('analyze').addEventListener('click',requestAnalysis);$('applyBest').addEventListener('click',applyBest);$('loadFen').addEventListener('click',loadFen);
  $('depth').addEventListener('change',()=>{if(engineReady)requestAnalysis();});$('multipv').addEventListener('change',()=>{if(engineReady)requestAnalysis();});
  // Render the playable board independently from engine startup. A missing engine must never blank the board.
  try { drawBoard(); } catch (e) { setStatus('Papan gagal dirender: '+(e&&e.message?e.message:String(e)), false); }
  try { initEngine(); } catch (e) { failEngine('Engine gagal dimulai: '+(e&&e.message?e.message:String(e))); }
})();