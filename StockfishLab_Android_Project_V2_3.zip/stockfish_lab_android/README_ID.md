# Stockfish Lab V2.2 — Proyek Android + Website Static

Stockfish Lab V2.2 adalah aplikasi analisis catur yang memakai Android WebView, HTML/CSS/JavaScript, chess.js 1.4.0 untuk aturan catur, dan Stockfish.js 19.0.1 Lite single-threaded untuk analisis.

## Perbaikan V2.2

- Memperbaiki halaman blank: tersedia papan awal sebagai fallback visual, sedangkan bundle interaktif `assets/main.js` dibuat saat build.
- Menambahkan pesan error yang jelas jika `main.js` tidak ter-deploy.
- Menambahkan timeout inisialisasi engine, penanganan `Worker.onerror`/`messageerror`, dan tombol coba ulang engine.
- Build workflow menghasilkan dua paket berbeda: APK Android dan website static untuk EdgeOne.
- Engine dan aturan catur dibundel lokal; tidak ada download engine dari CDN ketika halaman dibuka.

## Fitur

- Papan interaktif dengan pilih-bidak lalu kotak tujuan, atau drag-and-drop.
- Legal move validation termasuk rokade, en passant, promosi, skak, dan skakmat.
- Pilihan orientasi putih/hitam di bawah.
- Analisis otomatis setelah langkah atau analisis manual.
- Langkah terbaik, evaluasi, depth, waktu, dan hingga 5 variasi.
- Terapkan langkah terbaik untuk meninjau posisi, Undo, Redo, Reset, riwayat, dan input FEN.

## Build melalui GitHub Actions

ZIP ini adalah source project; ZIP ini bukan paket website siap unggah. Upload `StockfishLab_Android_Project_V2_2.zip` ke root repository, lalu ganti `.github/workflows/build.yml` dengan file `StockfishLab_V2_2_build.yml` yang disediakan terpisah. Commit changes.

Workflow membundel `main-entry.js` + chess.js menjadi `assets/main.js`, mengambil file Stockfish JS/WASM, mengompilasi APK, dan membuat folder website siap deploy.

## Deploy website ke EdgeOne

Dari GitHub Actions, unduh artifact `StockfishLab-Web-Dist`, ekstrak, lalu upload seluruh ISI folder hasil ekstrak ke root static website. Struktur harus dipertahankan:

- `index.html`
- `assets/main.js`
- `engine/stockfish-19-lite-single.js`
- `engine/stockfish-19-lite-single.wasm`

Jangan upload ZIP source Android mentah ke EdgeOne. Pastikan file `.wasm` disajikan dengan MIME `application/wasm`.

## Install APK

Unduh artifact `StockfishLab-V2.2-APK` dari workflow yang berhasil. Ekstrak artifact dan install `app-debug.apk`. Jika Android melaporkan konflik tanda tangan, uninstall versi lama dahulu.

## Versi dan lisensi

- versionCode: 3
- versionName: 2.2
- Minimum Android: API 24
- Stockfish.js 19.0.1: GPL-3.0
- chess.js 1.4.0: BSD-2-Clause

Lihat `THIRD_PARTY_NOTICES.txt`.


## StockfishLab V2.3 — perbaikan papan dan analisis otomatis

- Papan dirender terpisah dari proses startup engine, sehingga kegagalan engine tidak mengosongkan papan.
- `main-entry.js` harus dibundle bersama `chess.js` menjadi `assets/main.js` oleh workflow.
- Engine Stockfish 19 Lite single-threaded dan file WASM disalin ke `assets/engine/` saat workflow berjalan.
- Untuk website EdgeOne, deploy isi artifact `StockfishLab-Web-Dist` ke root hosting; jangan deploy ZIP source Android mentah.
- Untuk Android, instal artifact APK dari workflow setelah build sukses.
- Auto-analysis aktif secara default: analisis posisi awal setelah engine siap dan analisis ulang setelah setiap langkah legal.

Build perlu diuji melalui GitHub Actions dan browser/HP setelah deploy.
