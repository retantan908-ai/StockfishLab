package com.shin.studyassistant

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

// Situs AI yang dibuka di dalam app. Ganti sesuai keinginan.
const val AI_URL = "https://chatgpt.com/"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShinApp() }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AiWebScreen(onClose: () -> Unit) {
    var webView by remember { mutableStateOf<WebView?>(null) }
    BackHandler {
        val w = webView
        if (w != null && w.canGoBack()) w.goBack() else onClose()
    }
    Column(Modifier.fillMaxSize().background(Color(0xFF101018))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            TextButton(onClick = onClose) { Text("← Kembali") }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { webView?.reload() }) { Text("Muat ulang") }
        }
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
                loadUrl(AI_URL)
                webView = this
            }
        })
    }
}

@Composable
fun ShinApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("Pilih gambar atau ketik soal untuk mulai.") }
    var busy by remember { mutableStateOf(false) }
    var showWeb by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            busy = true
            try {
                val image = InputImage.fromFilePath(context, uri)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { result ->
                        question = result.text
                        answer = if (result.text.isBlank()) "Teks tidak ditemukan. Coba gambar lebih jelas." else "Teks terbaca. Periksa dulu, lalu minta AI menjelaskan."
                        busy = false
                    }.addOnFailureListener { e -> answer = "OCR gagal: ${e.localizedMessage}"; busy = false }
            } catch (e: Exception) { answer = "Gagal membuka gambar: ${e.localizedMessage}"; busy = false }
        }
    }
    if (showWeb) { AiWebScreen { showWeb = false }; return }
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFFFD54F), secondary = Color(0xFFFF6D8A), background = Color(0xFF101018), surface = Color(0xFF211A30))) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF101018)) {
            Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF321A48), Color(0xFF101018)))).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("SHIN!", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Black, color = Color(0xFFFFD54F))
                Text("STUDY ASSISTANT • COMIC AI", color = Color(0xFFFF8FA3), fontWeight = FontWeight.Bold)
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF292238)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("01 / SCAN SOAL", color = Color(0xFFFFD54F), fontWeight = FontWeight.Black)
                        Button(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("Pilih screenshot / foto soal") }
                        OutlinedTextField(question, { question = it }, modifier = Modifier.fillMaxWidth(), minLines = 4, label = { Text("Teks soal") })
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF292238)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("02 / BUKA AI", color = Color(0xFFFFD54F), fontWeight = FontWeight.Black)
                        Button(enabled = question.isNotBlank(), onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("soal", question))
                            Toast.makeText(context, "Soal disalin. Tempel di kolom chat AI.", Toast.LENGTH_LONG).show()
                            showWeb = true
                        }, modifier = Modifier.fillMaxWidth()) { Text("Salin soal & buka AI") }
                        OutlinedButton(onClick = { showWeb = true }, modifier = Modifier.fillMaxWidth()) { Text("Buka AI saja") }
                        Text(answer, color = Color.White)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF292238)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("03 / FLOATING BUBBLE", color = Color(0xFFFFD54F), fontWeight = FontWeight.Black)
                        Button(onClick = {
                            if (!Settings.canDrawOverlays(context)) context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                            else context.startService(Intent(context, FloatingService::class.java))
                        }, modifier = Modifier.fillMaxWidth()) { Text("Aktifkan floating bubble") }
                        OutlinedButton(onClick = { context.stopService(Intent(context, FloatingService::class.java)) }, modifier = Modifier.fillMaxWidth()) { Text("Matikan bubble") }
                    }
                }
                Text("Jawaban AI adalah bahan belajar. Periksa kembali sebelum digunakan.", color = Color.LightGray)
            }
        }
    }
}
