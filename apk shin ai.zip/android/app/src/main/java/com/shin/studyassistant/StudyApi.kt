package com.shin.studyassistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object StudyApi {
    // Replace with your deployed HTTPS backend URL (no trailing slash).
    const val BASE_URL = "https://YOUR-BACKEND.example"
    // Development convenience only. For a public app use proper user auth;
    // any token embedded in an APK can be extracted.
    const val APP_TOKEN = "SHIN"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    fun ask(question: String): String {
        val payload = JSONObject().put("question", question).put("mode", "explain")
        val request = Request.Builder()
            .url("$BASE_URL/api/study")
            .addHeader("x-app-token", APP_TOKEN)
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            val json = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
            if (!response.isSuccessful) throw IllegalStateException(json.optString("error", "HTTP ${response.code}"))
            return json.optString("answer").ifBlank { throw IllegalStateException("Jawaban AI kosong.") }
        }
    }
}
