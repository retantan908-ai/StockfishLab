package com.shin.studyassistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: TextView? = null
    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager; showBubble() }
    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(w, h,
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 12; y = 240 }
    private fun showBubble() {
        val b = TextView(this).apply { text = "SHIN"; textSize = 14f; setTextColor(-1); setBackgroundColor(0xFF9C36D8.toInt()); gravity = Gravity.CENTER; setPadding(20,16,20,16) }
        bubble = b
        val p = lp(-2,-2)
        var downX=0; var downY=0; var startX=0; var startY=0
        b.setOnTouchListener { _, e ->
            when(e.action) {
                MotionEvent.ACTION_DOWN -> { downX=e.rawX.toInt(); downY=e.rawY.toInt(); startX=p.x; startY=p.y; true }
                MotionEvent.ACTION_MOVE -> { p.x=startX+e.rawX.toInt()-downX; p.y=startY+e.rawY.toInt()-downY; wm.updateViewLayout(b,p); true }
                MotionEvent.ACTION_UP -> { if(kotlin.math.abs(e.rawX.toInt()-downX)<8 && kotlin.math.abs(e.rawY.toInt()-downY)<8) toggle(); true }
                else -> true
            }
        }
        wm.addView(b,p)
    }
    private fun toggle() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {}; panel=null; return }
        val v=TextView(this).apply {
            text="SHIN QUICK PANEL\n\nBuka aplikasi utama untuk scan soal dan memakai  AI.\nBubble bisa digeser di layar."
            textSize=15f; setTextColor(-1); setBackgroundColor(0xFF2B1C3C.toInt()); setPadding(26,26,26,26)
        }
        panel=v; wm.addView(v,lp(600,360))
    }
    override fun onDestroy() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
