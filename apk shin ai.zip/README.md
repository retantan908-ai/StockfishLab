# SHIN Study Assistant — Online AI build

This is a real app + backend starter wired for NVIDIA's OpenAI-compatible chat-completions API.
The Android app never contains the NVIDIA API key. The key is stored only in the backend environment.

## Security first
A secret key was pasted into chat. Treat it as exposed: revoke/rotate it in the provider dashboard before deploying. Do not paste the replacement into source code, Git, screenshots, or the APK.

## Project layout
- `android/` — Android Kotlin + Jetpack Compose app, image OCR, floating overlay bubble, study-answer UI.
- `server/` — Node.js backend that calls NVIDIA API.
- `server/.env.example` — environment variable template.

## 1. Configure backend
Install Node.js 20+.
```bash
cd server
cp .env.example .env
```
Edit `.env` locally:
- `NVIDIA_API_KEY=your_rotated_key`
- `NVIDIA_MODEL=meta/llama-3.1-8b-instruct` (change to a model enabled for your NVIDIA account)
- `PORT=8787`
- `APP_TOKEN=make-a-long-random-token`

Install and run:
```bash
npm install
npm start
```
The API is `POST /api/study` and expects:
```json
{"question":"...","mode":"explain"}
```
Send header `x-app-token: <APP_TOKEN>`.
The backend returns `{"answer":"..."}`.

For production, deploy this server on HTTPS hosting. Do not expose it on public HTTP.

## 2. Configure Android app
Open `android/` in Android Studio. In `android/app/src/main/java/com/shin/studyassistant/StudyApi.kt`, set `BASE_URL` to your HTTPS backend URL and `APP_TOKEN` to a per-app token. For a public release, replace the static app token with proper user authentication/rate limits; a token embedded in an APK can be extracted.
Then Build > Build APK(s).

## Notes / limitations
- Image OCR uses ML Kit on user-selected images.
- Floating bubble uses Android overlay permission and can be dragged. Android manufacturer restrictions may affect overlays.
- This starter does not secretly capture other apps. Full-screen capture must use Android's system MediaProjection consent and foreground-service requirements.
- The app sends the recognized/typed question to your configured backend only when you tap the AI button.
- This is a study assistant; it explains and helps solve practice material rather than concealing activity during exams.
