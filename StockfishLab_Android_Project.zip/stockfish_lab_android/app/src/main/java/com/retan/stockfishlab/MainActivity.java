package com.retan.stockfishlab;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String ENGINE_VERSION = "19.0.1";
    private static final String ENGINE_JS = "stockfish-19-lite-single.js";
    private static final String ENGINE_WASM = "stockfish-19-lite-single.wasm";
    private static final String CDN_BASE = "https://cdn.jsdelivr.net/npm/stockfish@" + ENGINE_VERSION + "/bin/";

    private WebView webView;
    private TextView loadingText;
    private ProgressBar progressBar;
    private File engineDirectory;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9, 13, 22));
        getWindow().setNavigationBarColor(Color.rgb(9, 13, 22));
        buildContainer();
        engineDirectory = new File(getFilesDir(), "stockfish-engine");
        if (!engineDirectory.exists() && !engineDirectory.mkdirs()) {
            showError("Folder engine tidak bisa dibuat. Coba pasang ulang aplikasi.");
            return;
        }
        prepareEngine();
    }

    private void buildContainer() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(9, 13, 22));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        FrameLayout loading = new FrameLayout(this);
        loading.setBackgroundColor(Color.rgb(9, 13, 22));
        loadingText = new TextView(this);
        loadingText.setTextColor(Color.WHITE);
        loadingText.setTextSize(15);
        loadingText.setGravity(Gravity.CENTER);
        loadingText.setText("Menyiapkan Stockfish...");
        progressBar = new ProgressBar(this);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(90, 90, Gravity.CENTER);
        p.bottomMargin = 96;
        loading.addView(progressBar, p);
        FrameLayout.LayoutParams t = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        t.topMargin = 74;
        loading.addView(loadingText, t);
        root.addView(loading, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        loading.setTag("loadingOverlay");
    }

    private void prepareEngine() {
        File js = new File(engineDirectory, ENGINE_JS);
        File wasm = new File(engineDirectory, ENGINE_WASM);
        if (js.isFile() && wasm.isFile() && js.length() > 100_000 && wasm.length() > 100_000) {
            openApp();
            return;
        }
        executor.execute(() -> {
            try {
                downloadIfNeeded(CDN_BASE + ENGINE_JS, js);
                runOnUiThread(() -> loadingText.setText("Engine hampir siap..."));
                downloadIfNeeded(CDN_BASE + ENGINE_WASM, wasm);
                runOnUiThread(this::openApp);
            } catch (Exception e) {
                runOnUiThread(() -> showError("Gagal mengunduh engine Stockfish. Periksa internet lalu buka ulang aplikasi.\n\n" + e.getMessage()));
            }
        });
    }

    private void downloadIfNeeded(String address, File destination) throws IOException {
        if (destination.isFile() && destination.length() > 100_000) return;
        File temp = new File(destination.getAbsolutePath() + ".part");
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(60000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("User-Agent", "StockfishLab-Android/1.0");
        try {
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new IOException("HTTP " + status + " saat mengambil engine.");
            try (InputStream in = connection.getInputStream(); FileOutputStream out = new FileOutputStream(temp)) {
                byte[] buffer = new byte[16 * 1024];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
                out.getFD().sync();
            }
            if (!temp.renameTo(destination)) {
                if (destination.exists()) destination.delete();
                if (!temp.renameTo(destination)) throw new IOException("Tidak bisa menyimpan file engine.");
            }
        } finally {
            connection.disconnect();
            if (temp.exists()) temp.delete();
        }
    }

    private void openApp() {
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/engine/", path -> {
                    try {
                        File file = new File(engineDirectory, path);
                        String root = engineDirectory.getCanonicalPath() + File.separator;
                        if (!file.getCanonicalPath().startsWith(root) || !file.isFile()) return null;
                        String mime = path.endsWith(".wasm") ? "application/wasm" : "text/javascript";
                        return new WebResourceResponse(mime, "UTF-8", new FileInputStream(file));
                    } catch (IOException e) {
                        return null;
                    }
                })
                .build();

        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        View loading = (View) ((FrameLayout) webView.getParent()).findViewWithTag("loadingOverlay");
        if (loading != null) loading.setVisibility(View.GONE);
    }

    private void showError(String message) {
        if (loadingText != null) loadingText.setText(message);
        if (progressBar != null) progressBar.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
