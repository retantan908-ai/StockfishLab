package com.retan.stockfishlab;

import java.util.Arrays;
import java.util.Locale;

/**
 * Pengenal papan catur dari screenshot (Java murni, tanpa dependensi Android agar mudah diuji).
 *
 * Alur: findBoard() -> extract() -> calibrate() / recognize().
 * - Papan dicari lewat pola kotak-catur 8x8 (dua warna bergantian) lalu disejajarkan dengan garis grid.
 * - Bidak dikenali lewat template-matching pada peta gradien (tidak bergantung warna kotak),
 *   warna bidak (putih/hitam) lewat kecerahan badan bidak. Template dipelajari sekali dari posisi
 *   yang diketahui (kalibrasi), sehingga cocok untuk set bidak apa pun.
 *
 * Indeks kotak "layar": row*8+col dengan row 0 = baris paling atas pada layar.
 * Indeks kotak "kanonik": 0 = a8 ... 7 = h8 ... 63 = h1 (urutan FEN).
 */
public final class BoardRecognizer {
    private BoardRecognizer() { }

    public static final int N = 24;
    /** Urutan indeks template. */
    public static final String PIECES = "KQRBNPkqrbnp";
    public static final String START_PLACEMENT = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";

    private static final double MIN_BOARD_SCORE = 0.60;
    private static final float MIN_CORR = 0.50f;
    private static final double OCC_FRACTION = 0.10;

    // ------------------------------------------------------------------ tipe data

    public static final class Img {
        public final int[] px; public final int[] lum; public final int w, h;
        public Img(int[] px, int w, int h) {
            this.px = px; this.w = w; this.h = h;
            lum = new int[w * h];
            for (int i = 0; i < lum.length; i++) lum[i] = luma(px[i]);
        }
    }

    public static final class Board {
        public final int x, y, size; public final double score;
        /** Warna kotak genap/ganjil ((row+col)%2) bila ditemukan lewat pasangan-warna; 0 jika tidak diketahui. */
        public final int ca, cb;
        Board(int x, int y, int size, double score) { this(x, y, size, score, 0, 0); }
        Board(int x, int y, int size, double score, int ca, int cb) {
            this.x = x; this.y = y; this.size = size; this.score = score; this.ca = ca; this.cb = cb;
        }
    }

    public static final class Frame {
        public Board board;
        public final boolean[] occ = new boolean[64];
        public final float[][] vec = new float[64][];
        public final float[] body = new float[64];
        public final boolean[] highlighted = new boolean[64];
    }

    public static final class Calibration {
        public final float[][] tpl = new float[12][];
        /** [0]=putih,[1]=hitam ; indeks kedua = paritas kotak (row+col)%2. NaN = belum diketahui. */
        public final float[][] body = {{Float.NaN, Float.NaN}, {Float.NaN, Float.NaN}};

        public boolean complete() { for (float[] t : tpl) if (t == null) return false; return true; }
        public int count() { int n = 0; for (float[] t : tpl) if (t != null) n++; return n; }

        public String serialize() {
            StringBuilder sb = new StringBuilder("v2|");
            for (int c = 0; c < 2; c++) for (int p = 0; p < 2; p++) sb.append(body[c][p]).append(',');
            sb.append('|');
            for (int i = 0; i < 12; i++) {
                if (tpl[i] != null) for (float v : tpl[i]) sb.append(String.format(Locale.US, "%.4f", v)).append(',');
                sb.append('|');
            }
            return sb.toString();
        }

        public static Calibration parse(String s) {
            Calibration cal = new Calibration();
            if (s == null || !s.startsWith("v2|")) return cal;
            try {
                String[] parts = s.split("\\|", -1);
                String[] b = parts[1].split(",");
                for (int c = 0; c < 2; c++) for (int p = 0; p < 2; p++) cal.body[c][p] = Float.parseFloat(b[c * 2 + p]);
                for (int i = 0; i < 12; i++) {
                    String t = parts[2 + i];
                    if (t.isEmpty()) continue;
                    String[] v = t.split(",");
                    if (v.length != N * N) continue;
                    float[] f = new float[N * N];
                    for (int k = 0; k < f.length; k++) f[k] = Float.parseFloat(v[k]);
                    cal.tpl[i] = f;
                }
            } catch (Exception e) { return new Calibration(); }
            return cal;
        }
    }

    public static final class Result {
        public boolean ok; public String error;
        public char[] screen = new char[64];     // ' ' = kosong
        public char[] canon = new char[64];
        public boolean whiteAtBottom = true;
        public float confidence; public int rejected;
        public char moverGuess;                  // 'w'/'b'/0 dari sorotan langkah terakhir
        public Board board;
        public String placement() { return placementOf(canon); }
    }

    // ------------------------------------------------------------------ util warna

    static int luma(int p) { return (299 * ((p >> 16) & 255) + 587 * ((p >> 8) & 255) + 114 * (p & 255)) / 1000; }
    static int rr(int p) { return (p >> 16) & 255; }
    static int gg(int p) { return (p >> 8) & 255; }
    static int bb(int p) { return p & 255; }
    static int dist(int a, int b) { return Math.abs(rr(a) - rr(b)) + Math.abs(gg(a) - gg(b)) + Math.abs(bb(a) - bb(b)); }

    private static int median(int[] a, int n) {
        int[] c = Arrays.copyOf(a, n); Arrays.sort(c); return c[n / 2];
    }
    private static int medianColor(int[] px, int n) {
        int[] r = new int[n], g = new int[n], b = new int[n];
        for (int i = 0; i < n; i++) { r[i] = rr(px[i]); g[i] = gg(px[i]); b[i] = bb(px[i]); }
        return 0xFF000000 | (median(r, n) << 16) | (median(g, n) << 8) | median(b, n);
    }

    private static int at(Img im, double x, double y) {
        int xi = (int) Math.round(x), yi = (int) Math.round(y);
        if (xi < 0) xi = 0; if (yi < 0) yi = 0; if (xi >= im.w) xi = im.w - 1; if (yi >= im.h) yi = im.h - 1;
        return im.px[yi * im.w + xi];
    }

    // ------------------------------------------------------------------ cari papan

    private static final double[] CF = {0.12, 0.88};

    /** Cek cepat blok 2x2 kotak pada (br,bc). Mengembalikan false jika bukan pola dua-warna. */
    private static boolean block(Img im, double x0, double y0, double q, int br, int bc, int[] outA, int[] outB) {
        int[] sa = new int[8], sb = new int[8]; int na = 0, nb = 0;
        for (int dr = 0; dr < 2; dr++) for (int dc = 0; dc < 2; dc++) {
            boolean a = ((dr + dc) & 1) == 0;
            for (double fy : CF) for (double fx : CF) {
                int p = at(im, x0 + (bc + dc + fx) * q, y0 + (br + dr + fy) * q);
                if (a) sa[na++] = p; else sb[nb++] = p;
            }
        }
        int ma = meanColor(sa), mb = meanColor(sb);
        if (dist(ma, mb) < 30) return false;
        int bad = 0;
        for (int i = 0; i < 8; i++) { if (dist(sa[i], ma) > 60) bad++; if (dist(sb[i], mb) > 60) bad++; }
        if (bad > 3) return false;
        outA[0] = ma; outB[0] = mb;
        return true;
    }

    private static int meanColor(int[] a) {
        int r = 0, g = 0, b = 0;
        for (int p : a) { r += rr(p); g += gg(p); b += bb(p); }
        int n = a.length;
        return 0xFF000000 | ((r / n) << 16) | ((g / n) << 8) | (b / n);
    }

    private static boolean quick(Img im, int x0, int y0, int s) {
        double q = s / 8.0;
        int[][] pos = {{0, 0}, {0, 6}, {6, 0}, {6, 6}};
        int fails = 0, passes = 0; int refA = 0, refB = 0;
        int[] oa = new int[1], ob = new int[1];
        for (int[] p : pos) {
            if (block(im, x0, y0, q, p[0], p[1], oa, ob)) {
                if (passes > 0 && (dist(oa[0], refA) > 60 || dist(ob[0], refB) > 60)) { fails++; }
                else { if (passes == 0) { refA = oa[0]; refB = ob[0]; } passes++; }
            } else fails++;
            if (fails >= 2) return false;
        }
        return passes >= 3;
    }

    /** Skor penuh: porsi sampel sudut-kotak yang konsisten dengan dua warna papan. */
    private static double fullScore(Img im, int x0, int y0, int s) {
        double q = s / 8.0;
        int[] a = new int[128], b = new int[128]; int na = 0, nb = 0;
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            for (double fy : CF) for (double fx : CF) {
                int p = at(im, x0 + (c + fx) * q, y0 + (r + fy) * q);
                if (((r + c) & 1) == 0) { if (na < 128) a[na++] = p; } else { if (nb < 128) b[nb++] = p; }
            }
        }
        // sampel ke-n tiap grup: 32 kotak x 4 = 128
        int ma = medianColor(a, na), mb = medianColor(b, nb);
        if (dist(ma, mb) < 30) return 0;
        int ia = 0, ib = 0;
        for (int i = 0; i < na; i++) if (dist(a[i], ma) <= 40) ia++;
        for (int i = 0; i < nb; i++) if (dist(b[i], mb) <= 40) ib++;
        return (ia / (double) na) * (ib / (double) nb);
    }

    /** Energi tepi sepanjang garis grid internal; puncak = penyejajaran tepat. */
    private static double edgeScore(Img im, int x0, int y0, int s) {
        double q = s / 8.0; double e = 0;
        for (int k = 1; k < 8; k++) {
            int gx = (int) Math.round(x0 + k * q), gy = (int) Math.round(y0 + k * q);
            for (int t = 0; t < s; t += 2) {
                int py = y0 + t, px = x0 + t;
                if (gx - 2 >= 0 && gx + 2 < im.w && py >= 0 && py < im.h)
                    e += Math.abs(im.lum[py * im.w + gx + 2] - im.lum[py * im.w + gx - 2]);
                if (gy - 2 >= 0 && gy + 2 < im.h && px >= 0 && px < im.w)
                    e += Math.abs(im.lum[(gy + 2) * im.w + px] - im.lum[(gy - 2) * im.w + px]);
            }
        }
        return e;
    }

    /** Pakai ulang posisi papan sebelumnya jika masih cocok (jauh lebih cepat daripada mencari ulang). */
    public static Board verify(Img im, Board b) {
        if (b == null || b.x < 0 || b.y < 0 || b.x + b.size > im.w || b.y + b.size > im.h) return null;
        if (b.ca != 0 || b.cb != 0) { double sc = colorScore(im, b); return sc >= 0.75 ? new Board(b.x, b.y, b.size, sc, b.ca, b.cb) : null; }
        double sc = fullScore(im, b.x, b.y, b.size);
        return sc >= MIN_BOARD_SCORE ? new Board(b.x, b.y, b.size, sc) : null;
    }

    // ---- pencari utama: pasangan warna kotak + integral image (tahan terhadap bidak besar)

    private static int[] integral(Img im, int c, int tol) {
        int w = im.w, h = im.h; int[] I = new int[(w + 1) * (h + 1)];
        for (int y = 0; y < h; y++) {
            int run = 0;
            for (int x = 0; x < w; x++) {
                if (dist(im.px[y * w + x], c) <= tol) run++;
                I[(y + 1) * (w + 1) + x + 1] = I[y * (w + 1) + x + 1] + run;
            }
        }
        return I;
    }
    private static int rect(int[] I, int w1, int x0, int y0, int x1, int y1) {
        return I[y1 * w1 + x1] - I[y0 * w1 + x1] - I[y1 * w1 + x0] + I[y0 * w1 + x0];
    }

    /** Skor: jumlah kotak (0..64) yang latarnya cocok dengan warna paritasnya; ca = warna kotak genap. */
    private static int gridScore(int[] IA, int[] IB, int w1, int x0, int y0, int s) {
        double q = s / 8.0; int ok1 = 0, ok2 = 0;
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            int xa = (int) Math.round(x0 + (c + 0.1) * q), xb = (int) Math.round(x0 + (c + 0.9) * q);
            int ya = (int) Math.round(y0 + (r + 0.1) * q), yb = (int) Math.round(y0 + (r + 0.9) * q);
            double area = Math.max(1, (xb - xa) * (yb - ya));
            double fa = rect(IA, w1, xa, ya, xb, yb) / area, fb = rect(IB, w1, xa, ya, xb, yb) / area;
            boolean even = ((r + c) & 1) == 0;
            if (even ? (fa >= 0.30 && fa > fb + 0.2) : (fb >= 0.30 && fb > fa + 0.2)) ok1++;
            if (even ? (fb >= 0.30 && fb > fa + 0.2) : (fa >= 0.30 && fa > fb + 0.2)) ok2++;
        }
        return Math.max(ok1, ok2) | (ok1 >= ok2 ? 0 : 1 << 16);   // bit 16 = penetapan ditukar
    }

    private static final int CTOL = 30;

    private static double contScore(int[] IA, int[] IB, int w1, int x0, int y0, int s, boolean swap) {
        double q = s / 8.0, tot = 0;
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            int xa = (int) Math.round(x0 + (c + 0.04) * q), xb = (int) Math.round(x0 + (c + 0.96) * q);
            int ya = (int) Math.round(y0 + (r + 0.04) * q), yb = (int) Math.round(y0 + (r + 0.96) * q);
            double area = Math.max(1, (xb - xa) * (yb - ya));
            double fa = rect(IA, w1, xa, ya, xb, yb) / area, fb = rect(IB, w1, xa, ya, xb, yb) / area;
            boolean aExpected = (((r + c) & 1) == 0) != swap;
            tot += aExpected ? fa - fb : fb - fa;
        }
        return tot;
    }

    private static Board findByColors(Img im) {
        int w = im.w, h = im.h, n = w * h;
        int[] cnt = new int[4096]; long[] sr = new long[4096], sg = new long[4096], sb = new long[4096];
        for (int i = 0; i < n; i++) {
            int p = im.px[i]; int bin = ((rr(p) >> 4) << 8) | ((gg(p) >> 4) << 4) | (bb(p) >> 4);
            cnt[bin]++; sr[bin] += rr(p); sg[bin] += gg(p); sb[bin] += bb(p);
        }
        Integer[] order = new Integer[4096]; for (int i = 0; i < 4096; i++) order[i] = i;
        Arrays.sort(order, (a, b) -> cnt[b] - cnt[a]);
        int[] col = new int[10], ccount = new int[10]; int nc = 0;
        for (int k = 0; k < 24 && nc < 10; k++) {
            int b = order[k]; if (cnt[b] < n * 0.006) break;
            int c = 0xFF000000 | ((int) (sr[b] / cnt[b]) << 16) | ((int) (sg[b] / cnt[b]) << 8) | (int) (sb[b] / cnt[b]);
            boolean dup = false;                       // gabungkan bin tetangga yang warnanya hampir sama
            for (int j = 0; j < nc; j++) if (dist(col[j], c) <= 24) { ccount[j] += cnt[b]; dup = true; break; }
            if (!dup) { col[nc] = c; ccount[nc] = cnt[b]; nc++; }
        }
        int minDim = Math.min(w, h);
        double bestScore = 0; Board best = null; int tried = 0;
        // pasangan diurutkan: dua warna terbesar yang kontras dan sama luasnya lebih dulu
        for (int i = 0; i < nc && tried < 8; i++) for (int j = i + 1; j < nc && tried < 8; j++) {
            if (dist(col[i], col[j]) < 30) continue;
            double ratio = ccount[i] / (double) ccount[j];
            if (ratio < 0.35 || ratio > 2.9) continue;
            tried++;
            int[] IA = integral(im, col[i], CTOL), IB = integral(im, col[j], CTOL);
            int w1 = w + 1;
            // kotak pembatas dari proyeksi baris/kolom piksel bermasker
            int[] colP = new int[w], rowP = new int[h];
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
                int a = rect(IA, w1, x, y, x + 1, y + 1) + rect(IB, w1, x, y, x + 1, y + 1);
                if (a > 0) { colP[x]++; rowP[y]++; }
            }
            int[] cr = longestRun(colP, w), rw = longestRun(rowP, h);
            if (cr == null || rw == null) continue;
            int L = Math.min(cr[1] - cr[0] + 1, rw[1] - rw[0] + 1);
            if (L < 96) continue;
            int sLo = Math.max(96, (int) (L * 0.85)) & ~3, sHi = Math.min(minDim, (int) (L * 1.15));
            int bx = 0, by = 0, bs = 0, bsc = -1, bswap = 0;
            for (int s = sLo; s <= sHi; s += 4) {
                int xLo = Math.max(0, cr[0] - (int) (0.1 * L)), xHi = Math.min(w - s, cr[1] + (int) (0.1 * L) - s);
                int yLo = Math.max(0, rw[0] - (int) (0.1 * L)), yHi = Math.min(h - s, rw[1] + (int) (0.1 * L) - s);
                for (int y = yLo; y <= yHi; y += 4) for (int x = xLo; x <= xHi; x += 4) {
                    int g = gridScore(IA, IB, w1, x, y, s); int sc = g & 0xFFFF;
                    if (sc > bsc) { bsc = sc; bx = x; by = y; bs = s; bswap = g >> 16; }
                }
            }
            if (bsc < 0) continue;
            // penajaman halus (langkah 1 px) dengan skor kontinu: fraksi warna-sesuai dikurangi warna-lawan pada
            // seluruh kotak; puncaknya tepat di penyejajaran asli walau bidak besar menutupi kotak
            boolean swap = bswap != 0; double bc = -1e9; int fx = bx, fy = by, fs = bs;
            for (int ds = -10; ds <= 10; ds++) for (int dy = -10; dy <= 10; dy++) for (int dx = -10; dx <= 10; dx++) {
                int s = bs + ds, x = bx + dx, y = by + dy;
                if (s < 64 || x < 0 || y < 0 || x + s > w || y + s > h) continue;
                double c = contScore(IA, IB, w1, x, y, s, swap);
                if (c > bc) { bc = c; fx = x; fy = y; fs = s; }
            }
            // energi tepi garis grid menentukan posisi akhir (puncaknya tajam). Titik awal: hasil skor kontinu dan
            // kotak pembatas dari proyeksi; keduanya dicoba karena dataran skor bisa melenceng saat bidak besar.
            double ebest = -1; int ex = fx, ey = fy, es = fs;
            int[][] starts = {{fx, fy, fs}, {cr[0], rw[0], L}};
            for (int[] st : starts) {
                for (int ds = -30; ds <= 30; ds += 4) for (int dy = -30; dy <= 30; dy += 4) for (int dx = -30; dx <= 30; dx += 4) {
                    int s = st[2] + ds, x = st[0] + dx, y = st[1] + dy;
                    if (s < 64 || x < 0 || y < 0 || x + s > w || y + s > h) continue;
                    if ((gridScore(IA, IB, w1, x, y, s) & 0xFFFF) < bsc - 8) continue;
                    double e = edgeScore(im, x, y, s);
                    if (e > ebest) { ebest = e; ex = x; ey = y; es = s; }
                }
            }
            int cx0 = ex, cy0 = ey, cs0 = es;
            for (int ds = -3; ds <= 3; ds++) for (int dy = -3; dy <= 3; dy++) for (int dx = -3; dx <= 3; dx++) {
                int s = cs0 + ds, x = cx0 + dx, y = cy0 + dy;
                if (s < 64 || x < 0 || y < 0 || x + s > w || y + s > h) continue;
                double e = edgeScore(im, x, y, s);
                if (e > ebest) { ebest = e; ex = x; ey = y; es = s; }
            }
            fx = ex; fy = ey; fs = es;
            double score = (gridScore(IA, IB, w1, fx, fy, fs) & 0xFFFF) / 64.0;
            if (score >= 0.80 && score > bestScore) {
                bestScore = score;
                best = new Board(fx, fy, fs, score, swap ? col[j] : col[i], swap ? col[i] : col[j]);
            }
        }
        return best;
    }

    /** Rentang kontigu terpanjang dengan hitungan >= 30% dari maksimum (celah <= 4 px diabaikan). */
    private static int[] longestRun(int[] p, int n) {
        int max = 0; for (int i = 0; i < n; i++) max = Math.max(max, p[i]);
        if (max == 0) return null;
        int thr = (int) (max * 0.30); int bs = -1, be = -1, cs = -1, gap = 0;
        for (int i = 0; i < n; i++) {
            if (p[i] >= thr) { if (cs < 0) cs = i; gap = 0; if (be - bs < i - cs) { bs = cs; be = i; } }
            else if (cs >= 0 && ++gap > 4) cs = -1;
        }
        return bs < 0 ? null : new int[]{bs, be};
    }

    /** Skor langsung (tanpa integral) untuk memverifikasi papan yang sudah dikenal. */
    private static double colorScore(Img im, Board b) {
        int ok = 0; double q = b.size / 8.0;
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            int xa = (int) Math.round(b.x + (c + 0.1) * q), xb = (int) Math.round(b.x + (c + 0.9) * q);
            int ya = (int) Math.round(b.y + (r + 0.1) * q), yb = (int) Math.round(b.y + (r + 0.9) * q);
            int fe = 0, fo = 0, tot = 0;
            for (int y = ya; y < yb; y += 2) for (int x = xa; x < xb; x += 2) {
                int p = im.px[Math.min(im.h - 1, y) * im.w + Math.min(im.w - 1, x)]; tot++;
                if (dist(p, b.ca) <= CTOL) fe++; else if (dist(p, b.cb) <= CTOL) fo++;
            }
            boolean even = ((r + c) & 1) == 0; double fm = (even ? fe : fo) / (double) Math.max(1, tot), fx = (even ? fo : fe) / (double) Math.max(1, tot);
            if (fm >= 0.30 && fm > fx + 0.2) ok++;
        }
        return ok / 64.0;
    }

    public static Board findBoard(Img im) {
        Board b = findByColors(im);
        return b != null ? b : findLegacy(im);
    }

    private static Board findLegacy(Img im) {
        int minDim = Math.min(im.w, im.h);
        int sMin = Math.max(96, (int) (minDim * 0.30)) & ~7;
        double best = 0; int bx = 0, by = 0, bs = 0;
        // kandidat lolos cek cepat -> skor penuh
        for (int s = sMin; s <= minDim; s += 8) {
            for (int y = 0; y + s <= im.h; y += 4) {
                for (int x = 0; x + s <= im.w; x += 4) {
                    if (!quick(im, x, y, s)) continue;
                    double sc = fullScore(im, x, y, s);
                    if (sc > best + 1e-9) { best = sc; bx = x; by = y; bs = s; }
                }
            }
        }
        if (best < MIN_BOARD_SCORE) return null;
        // plateau: rata-ratakan semua parameter yang hampir sama bagusnya, lalu tajamkan dengan energi tepi
        double sx = 0, sy = 0, ss = 0; int cnt = 0;
        for (int ds = -8; ds <= 8; ds += 2) for (int dy = -8; dy <= 8; dy += 2) for (int dx = -8; dx <= 8; dx += 2) {
            int s = bs + ds, x = bx + dx, y = by + dy;
            if (s < 64 || x < 0 || y < 0 || x + s > im.w || y + s > im.h) continue;
            if (fullScore(im, x, y, s) >= best - 0.01) { sx += x; sy += y; ss += s; cnt++; }
        }
        int cx = cnt > 0 ? (int) Math.round(sx / cnt) : bx, cy = cnt > 0 ? (int) Math.round(sy / cnt) : by;
        int cs = cnt > 0 ? (int) Math.round(ss / cnt) : bs;
        double be = -1; int fx = cx, fy = cy, fs = cs;
        for (int ds = -10; ds <= 10; ds++) for (int dy = -10; dy <= 10; dy++) for (int dx = -10; dx <= 10; dx++) {
            int s = cs + ds, x = cx + dx, y = cy + dy;
            if (s < 64 || x < 0 || y < 0 || x + s > im.w || y + s > im.h) continue;
            double e = edgeScore(im, x, y, s);
            if (e > be) { be = e; fx = x; fy = y; fs = s; }
        }
        return new Board(fx, fy, fs, best);
    }

    // ------------------------------------------------------------------ fitur per kotak

    public static Frame extract(Img im, Board bd) {
        Frame f = new Frame(); f.board = bd;
        double q = bd.size / 8.0;
        int[] bgCol = new int[64]; boolean[] occ = f.occ;
        int[][] patch = new int[64][]; int[] patchN = new int[64];
        // 1) sampel latar dari 4 patch sudut tiap kotak
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            int idx = r * 8 + c; double sx = bd.x + c * q, sy = bd.y + r * q;
            int[] sc = new int[1200]; int n = 0;
            int step = Math.max(1, (int) (q * 0.15 / 4));
            for (int cy = 0; cy < 2; cy++) for (int cx = 0; cx < 2; cx++) {
                double ax = sx + (cx == 0 ? 0.05 : 0.80) * q, ay = sy + (cy == 0 ? 0.05 : 0.80) * q;
                for (double yy = ay; yy < ay + 0.15 * q && n < sc.length; yy += step)
                    for (double xx = ax; xx < ax + 0.15 * q && n < sc.length; xx += step) sc[n++] = at(im, xx, yy);
            }
            patch[idx] = sc; patchN[idx] = n;
        }
        // 2) warna acuan per paritas: dari pencari papan, atau modus warna seluruh patch
        int[] ref = new int[2];
        if (bd.ca != 0 || bd.cb != 0) { ref[0] = bd.ca; ref[1] = bd.cb; }
        else for (int p = 0; p < 2; p++) {
            int[] cnt = new int[4096]; long[] sr = new long[4096], sg = new long[4096], sb = new long[4096];
            for (int i = 0; i < 64; i++) if (parity(i) == p) for (int k = 0; k < patchN[i]; k++) {
                int px = patch[i][k]; int bin = ((rr(px) >> 4) << 8) | ((gg(px) >> 4) << 4) | (bb(px) >> 4);
                cnt[bin]++; sr[bin] += rr(px); sg[bin] += gg(px); sb[bin] += bb(px);
            }
            int bi = 0; for (int k = 1; k < 4096; k++) if (cnt[k] > cnt[bi]) bi = k;
            ref[p] = cnt[bi] == 0 ? 0xFF808080 : 0xFF000000 | ((int) (sr[bi] / cnt[bi]) << 16) | ((int) (sg[bi] / cnt[bi]) << 8) | (int) (sb[bi] / cnt[bi]);
        }
        // 3) latar akhir: warna acuan paritas bila cincin sudut didominasi warna itu (kotak biasa, walau bidak besar
        //    menutupi sudut); selain itu median lokal (kotak yang disorot)
        for (int idx = 0; idx < 64; idx++) {
            int n = patchN[idx]; int[] sc = patch[idx]; int R = ref[parity(idx)];
            int near = 0; for (int k = 0; k < n; k++) if (dist(sc[k], R) <= CTOL) near++;
            int local = medianColor(sc, n);
            bgCol[idx] = (n > 0 && near >= 0.22 * n) || dist(local, R) <= CTOL ? R : local;
        }
        for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) {
            int idx = r * 8 + c; double sx = bd.x + c * q, sy = bd.y + r * q; int bg = bgCol[idx];
            int noise = 0; int[] sc = patch[idx];
            for (int i = 0; i < patchN[idx]; i++) noise += Math.min(dist(sc[i], bg), 60);
            noise = patchN[idx] > 0 ? noise / patchN[idx] / 3 : 0;
            int thr = 48 + Math.min(noise, 20);
            int diff = 0, tot = 0;
            int x0 = (int) Math.round(sx + 0.15 * q), x1 = (int) Math.round(sx + 0.85 * q);
            int y0 = (int) Math.round(sy + 0.15 * q), y1 = (int) Math.round(sy + 0.85 * q);
            for (int yy = y0; yy < y1; yy++) for (int xx = x0; xx < x1; xx++) {
                tot++; if (dist(at(im, xx, yy), bg) > thr) diff++;
            }
            occ[idx] = tot > 0 && diff / (double) tot >= OCC_FRACTION;
            if (!occ[idx]) continue;
            f.vec[idx] = gradVector(im, sx, sy, q);
            f.body[idx] = bodyLuma(im, sx, sy, q);
        }
        // sorotan langkah terakhir: latar menyimpang dari warna acuan paritasnya
        for (int i = 0; i < 64; i++) f.highlighted[i] = dist(bgCol[i], ref[parity(i)]) > 45;
        return f;
    }

    // ------------------------------------------------------------------ penanda perubahan (mode auto tanpa menyembunyikan overlay)

    /** Tanda tangan luma 8x8 per kotak (4096 byte). */
    public static byte[] signature(Img im, Board bd) {
        byte[] sig = new byte[64 * 64]; double q = bd.size / 8.0, cell = q / 8.0;
        for (int sq = 0; sq < 64; sq++) {
            double sx = bd.x + (sq % 8) * q, sy = bd.y + (sq / 8) * q;
            for (int j = 0; j < 8; j++) for (int i = 0; i < 8; i++)
                sig[sq * 64 + j * 8 + i] = (byte) (luma(at(im, sx + (i + 0.5) * cell, sy + (j + 0.5) * cell)) >> 1);
        }
        return sig;
    }

    /** True bila ada kotak yang rata-rata luma-nya berubah cukup besar. */
    public static boolean signatureChanged(byte[] a, byte[] b) {
        if (a == null || b == null || a.length != b.length) return true;
        for (int sq = 0; sq < 64; sq++) {
            int d = 0; for (int k = 0; k < 64; k++) d += Math.abs((a[sq * 64 + k] & 255) - (b[sq * 64 + k] & 255));
            if (d / 64 >= 3) return true;   // ~6 tingkat luma
        }
        return false;
    }

    private static float[] gradVector(Img im, double sx, double sy, double q) {
        float[][] g = new float[N][N];
        double rx = sx + 0.10 * q, ry = sy + 0.10 * q, span = 0.80 * q, cell = span / N;
        for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
            int xa = (int) Math.floor(rx + i * cell), xb = Math.max(xa + 1, (int) Math.floor(rx + (i + 1) * cell));
            int ya = (int) Math.floor(ry + j * cell), yb = Math.max(ya + 1, (int) Math.floor(ry + (j + 1) * cell));
            long sum = 0; int cnt = 0;
            for (int y = ya; y < yb; y++) for (int x = xa; x < xb; x++) {
                int xc = Math.min(im.w - 1, Math.max(0, x)), yc = Math.min(im.h - 1, Math.max(0, y));
                sum += im.lum[yc * im.w + xc]; cnt++;
            }
            g[j][i] = cnt > 0 ? sum / (float) cnt : 0;
        }
        float[] v = new float[N * N]; double mean = 0;
        for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
            int jm = Math.max(0, j - 1), jp = Math.min(N - 1, j + 1), im_ = Math.max(0, i - 1), ip = Math.min(N - 1, i + 1);
            float gx = (g[jm][ip] + 2 * g[j][ip] + g[jp][ip]) - (g[jm][im_] + 2 * g[j][im_] + g[jp][im_]);
            float gy = (g[jp][im_] + 2 * g[jp][i] + g[jp][ip]) - (g[jm][im_] + 2 * g[jm][i] + g[jm][ip]);
            float m = (float) Math.sqrt(gx * gx + gy * gy);
            v[j * N + i] = m; mean += m;
        }
        return normalize(v);
    }

    private static float[] normalize(float[] v) {
        double mean = 0; for (float x : v) mean += x; mean /= v.length;
        double n = 0; for (int i = 0; i < v.length; i++) { v[i] -= mean; n += v[i] * v[i]; }
        n = Math.sqrt(n);
        if (n < 1e-6) return v;
        for (int i = 0; i < v.length; i++) v[i] /= n;
        return v;
    }

    /** Korelasi dengan toleransi geser +-1 sel (menyerap selisih penyejajaran/skala kecil). */
    private static float dot(float[] a, float[] b) {
        float best = -2;
        for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
            float s = 0;
            for (int j = Math.max(0, -dy); j < Math.min(N, N - dy); j++)
                for (int i = Math.max(0, -dx); i < Math.min(N, N - dx); i++)
                    s += a[(j + dy) * N + i + dx] * b[j * N + i];
            if (s > best) best = s;
        }
        return best;
    }

    private static float bodyLuma(Img im, double sx, double sy, double q) {
        int[] t = new int[2500]; int n = 0;
        for (double y = sy + 0.50 * q; y < sy + 0.78 * q && n < t.length; y += 1)
            for (double x = sx + 0.35 * q; x < sx + 0.65 * q && n < t.length; x += 1) t[n++] = luma(at(im, x, y));
        return n > 0 ? median(t, n) : 128;
    }

    private static int parity(int idx) { return ((idx / 8) + (idx % 8)) & 1; }

    // ------------------------------------------------------------------ kalibrasi

    /**
     * Pelajari template dari layar yang menampilkan posisi dengan penempatan bidak {@code placement} (bagian pertama FEN).
     * Mengembalikan jumlah jenis bidak yang dipelajari, atau -1 jika posisi layar tidak cocok (pesan di err[0]).
     */
    public static int calibrate(Frame f, String placement, Calibration cal, String[] err) {
        char[] canon = canonFromPlacement(placement);
        if (canon == null) { err[0] = "FEN kalibrasi tidak valid."; return -1; }
        int mm0 = 0, mm1 = 0;
        for (int i = 0; i < 64; i++) {
            if (f.occ[i] != (canon[i] != ' ')) mm0++;
            if (f.occ[i] != (canon[63 - i] != ' ')) mm1++;
        }
        boolean flipped = mm1 < mm0; int mm = Math.min(mm0, mm1);
        if (mm > 4) { err[0] = "Posisi di layar tidak cocok dengan FEN kalibrasi (" + mm + " kotak berbeda)."; return -1; }
        float[][] sum = new float[12][N * N]; int[] cnt = new int[12];
        java.util.ArrayList<Float>[][] bodies = new java.util.ArrayList[2][2];
        for (int c = 0; c < 2; c++) for (int p = 0; p < 2; p++) bodies[c][p] = new java.util.ArrayList<>();
        for (int i = 0; i < 64; i++) {
            char ch = canon[flipped ? 63 - i : i];
            if (ch == ' ' || !f.occ[i]) continue;
            int pi = PIECES.indexOf(ch);
            for (int k = 0; k < sum[pi].length; k++) sum[pi][k] += f.vec[i][k];
            cnt[pi]++;
            bodies[Character.isUpperCase(ch) ? 0 : 1][parity(i)].add(f.body[i]);
        }
        int learned = 0;
        for (int pi = 0; pi < 12; pi++) if (cnt[pi] > 0) { cal.tpl[pi] = normalize(sum[pi]); learned++; }
        for (int c = 0; c < 2; c++) for (int p = 0; p < 2; p++) {
            java.util.ArrayList<Float> l = bodies[c][p];
            if (l.isEmpty()) continue;
            float[] a = new float[l.size()]; for (int k = 0; k < a.length; k++) a[k] = l.get(k);
            Arrays.sort(a); cal.body[c][p] = a[a.length / 2];
        }
        return learned;
    }

    /** True jika okupansi layar menyerupai posisi awal (baik putih di bawah maupun di atas). */
    public static boolean looksLikeStart(Frame f) {
        char[] canon = canonFromPlacement(START_PLACEMENT);
        int mm0 = 0, mm1 = 0;
        for (int i = 0; i < 64; i++) {
            if (f.occ[i] != (canon[i] != ' ')) mm0++;
            if (f.occ[i] != (canon[63 - i] != ' ')) mm1++;
        }
        return Math.min(mm0, mm1) <= 2;
    }

    // ------------------------------------------------------------------ kenali

    public static Result recognize(Frame f, Calibration cal) {
        Result res = new Result(); res.board = f.board;
        if (!cal.complete()) { res.error = "Template bidak belum lengkap (" + cal.count() + "/12). Lakukan kalibrasi."; return res; }
        Arrays.fill(res.screen, ' ');
        float confSum = 0; int confN = 0;
        for (int i = 0; i < 64; i++) {
            if (!f.occ[i]) continue;
            int p = parity(i);
            float wb = cal.body[0][p], bl = cal.body[1][p];
            if (Float.isNaN(wb)) wb = cal.body[0][1 - p]; if (Float.isNaN(bl)) bl = cal.body[1][1 - p];
            boolean white = f.body[i] > (wb + bl) / 2f;
            int from = white ? 0 : 6;
            float best = -2; int bi = -1;
            for (int k = from; k < from + 6; k++) {
                float d = dot(f.vec[i], cal.tpl[k]);
                if (d > best) { best = d; bi = k; }
            }
            if (best < MIN_CORR) { res.rejected++; continue; }
            res.screen[i] = PIECES.charAt(bi);
            confSum += best; confN++;
        }
        res.confidence = confN > 0 ? confSum / confN : 0;
        // orientasi: rata-rata baris bidak putih vs hitam
        double wr = 0, br = 0; int wn = 0, bn = 0;
        for (int i = 0; i < 64; i++) {
            char ch = res.screen[i]; if (ch == ' ') continue;
            if (Character.isUpperCase(ch)) { wr += i / 8; wn++; } else { br += i / 8; bn++; }
        }
        res.whiteAtBottom = (wn == 0 || bn == 0) ? true : (wr / wn) > (br / bn);
        for (int i = 0; i < 64; i++) res.canon[res.whiteAtBottom ? i : 63 - i] = res.screen[i];
        int wk = 0, bk = 0;
        for (char ch : res.canon) { if (ch == 'K') wk++; if (ch == 'k') bk++; }
        if (wk != 1 || bk != 1) {
            res.error = "Raja tidak terdeteksi benar (putih " + wk + ", hitam " + bk + "). Pastikan papan terlihat utuh.";
            return res;
        }
        // pion di baris 1/8 mustahil
        for (int i = 0; i < 8; i++) if (res.canon[i] == 'P' || res.canon[i] == 'p' || res.canon[56 + i] == 'P' || res.canon[56 + i] == 'p') {
            res.error = "Hasil pengenalan tidak masuk akal (pion di baris tepi)."; return res;
        }
        // tebak penggerak terakhir dari sorotan kotak
        int cw = 0, cb = 0, hl = 0;
        for (int i = 0; i < 64; i++) if (f.highlighted[i]) {
            hl++; char ch = res.screen[i];
            if (ch != ' ') { if (Character.isUpperCase(ch)) cw++; else cb++; }
        }
        if (hl >= 1 && hl <= 4) { if (cw > 0 && cb == 0) res.moverGuess = 'w'; else if (cb > 0 && cw == 0) res.moverGuess = 'b'; }
        res.ok = true;
        return res;
    }

    // ------------------------------------------------------------------ FEN

    public static char[] canonFromPlacement(String placement) {
        char[] out = new char[64]; Arrays.fill(out, ' ');
        String[] rows = placement.trim().split("/");
        if (rows.length != 8) return null;
        for (int r = 0; r < 8; r++) {
            int c = 0;
            for (char ch : rows[r].toCharArray()) {
                if (ch >= '1' && ch <= '8') c += ch - '0';
                else if (PIECES.indexOf(ch) >= 0 && c < 8) out[r * 8 + c++] = ch;
                else return null;
            }
            if (c != 8) return null;
        }
        return out;
    }

    public static String placementOf(char[] canon) {
        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < 8; r++) {
            int empty = 0;
            for (int c = 0; c < 8; c++) {
                char ch = canon[r * 8 + c];
                if (ch == ' ') empty++; else { if (empty > 0) { sb.append(empty); empty = 0; } sb.append(ch); }
            }
            if (empty > 0) sb.append(empty);
            if (r < 7) sb.append('/');
        }
        return sb.toString();
    }
}
