package com.retan.stockfishlab;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

/** Offline-first chess analysis app with iOS Dark Liquid Glass UI. */
public class MainActivity extends Activity {
    private static final int OVERLAY_PERMISSION_REQUEST = 710;
    private WebView webView;
    private String pendingFen;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 11, 19));
        getWindow().setNavigationBarColor(Color.rgb(7, 11, 19));
        pendingFen = getIntent().getStringExtra("fen");
        buildContainer();
        openApp();
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void buildContainer() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(7, 11, 19));
        root.setFitsSystemWindows(true);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7, 11, 19));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));

        // iOS Dark Liquid Glass Floating Pill Button (Bottom-Right so it never clashes with status bar or top header)
        TextView floatButton = new TextView(this);
        floatButton.setText("❖  Float Mode");
        floatButton.setTextColor(Color.rgb(240, 253, 244));
        floatButton.setTextSize(12);
        floatButton.setTypeface(Typeface.DEFAULT_BOLD);
        floatButton.setGravity(Gravity.CENTER);
        floatButton.setPadding(dp(16), dp(11), dp(16), dp(11));

        GradientDrawable pillBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.argb(225, 24, 36, 54), Color.argb(215, 13, 20, 32)}
        );
        pillBg.setCornerRadius(dp(99));
        pillBg.setStroke(dp(1), Color.argb(75, 110, 231, 183));
        floatButton.setBackground(pillBg);
        floatButton.setElevation(dp(12));

        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        bp.setMargins(0, 0, dp(16), dp(20));
        root.addView(floatButton, bp);

        floatButton.setOnClickListener(v -> enableFloatingPanel());
        setContentView(root);
    }

    private void enableFloatingPanel() {
        if (android.os.Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, OVERLAY_PERMISSION_REQUEST);
        } else {
            startFloatingService();
        }
    }

    private void startFloatingService() {
        Intent service = new Intent(this, FloatingAnalysisService.class);
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service);
        else startService(service);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQUEST) {
            if (android.os.Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) startFloatingService();
        }
    }

    private void openApp() {
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/engine/", this::openEngineAsset)
                .build();
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (pendingFen != null && !pendingFen.trim().isEmpty()) {
                    String safe = org.json.JSONObject.quote(pendingFen);
                    view.evaluateJavascript("(function(){var f=document.getElementById('fen');var b=document.getElementById('loadFen');if(f&&b){f.value=" + safe + ";b.click();}})()", null);
                    pendingFen = null;
                }
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private WebResourceResponse openEngineAsset(String path) {
        try {
            InputStream input = getAssets().open("engine/" + path);
            String mime = path.endsWith(".wasm") ? "application/wasm" : "text/javascript";
            return new WebResourceResponse(mime, null, input);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null,
                    new ByteArrayInputStream(new byte[0]));
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
