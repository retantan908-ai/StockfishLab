package com.retan.stockfishlab;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Draggable floating FEN importer with iOS Dark Liquid Glass UI and Status Bar Protection. */
public class FloatingAnalysisService extends Service {
    private WindowManager windowManager;
    private View panel;
    private WindowManager.LayoutParams params;
    private EditText fenInput;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            String channelId = "stockfish_floating";
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(channelId, "Stockfish floating window", NotificationManager.IMPORTANCE_LOW));
            Notification notification = new Notification.Builder(this, channelId)
                    .setSmallIcon(android.R.drawable.ic_menu_info_details)
                    .setContentTitle("StockfishLab floating aktif")
                    .setContentText("Masukkan FEN secara manual untuk analisis")
                    .setOngoing(true)
                    .build();
            startForeground(7301, notification);
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showPanel();
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private int getStatusBarHeight() {
        int resId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resId > 0) return getResources().getDimensionPixelSize(resId);
        return dp(28);
    }

    private void showPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(12), dp(16), dp(16));

        // iOS Dark Liquid Glass container
        GradientDrawable glassBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.argb(235, 22, 30, 46), Color.argb(225, 11, 16, 26)}
        );
        glassBg.setCornerRadius(dp(26));
        glassBg.setStroke(dp(1), Color.argb(65, 255, 255, 255));
        box.setBackground(glassBg);
        box.setElevation(dp(24));

        // iOS Pill Grabber Handle
        View grabber = new View(this);
        GradientDrawable grabberBg = new GradientDrawable();
        grabberBg.setColor(Color.argb(90, 255, 255, 255));
        grabberBg.setCornerRadius(dp(4));
        grabber.setBackground(grabberBg);
        LinearLayout.LayoutParams grabParams = new LinearLayout.LayoutParams(dp(38), dp(4));
        grabParams.gravity = Gravity.CENTER_HORIZONTAL;
        grabParams.setMargins(0, 0, 0, dp(10));
        box.addView(grabber, grabParams);

        // Header bar (Draggable area)
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(8));

        TextView title = new TextView(this);
        title.setText("♞ Stockfish Lab");
        title.setTextColor(Color.rgb(52, 211, 153));
        title.setTextSize(15);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView badge = new TextView(this);
        badge.setText("GLASS");
        badge.setTextColor(Color.argb(200, 255, 255, 255));
        badge.setTextSize(9);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setPadding(dp(8), dp(3), dp(8), dp(3));
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(Color.argb(35, 255, 255, 255));
        badgeBg.setCornerRadius(dp(99));
        badgeBg.setStroke(dp(1), Color.argb(40, 255, 255, 255));
        badge.setBackground(badgeBg);
        header.addView(badge);

        box.addView(header);

        TextView hint = new TextView(this);
        hint.setText("Tempel FEN posisi latihan / permainan:");
        hint.setTextColor(Color.rgb(165, 180, 200));
        hint.setTextSize(11);
        box.addView(hint);

        fenInput = new EditText(this);
        fenInput.setText("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
        fenInput.setTextColor(Color.WHITE);
        fenInput.setTextSize(11);
        fenInput.setHintTextColor(Color.rgb(110, 125, 145));
        fenInput.setHint("Masukkan FEN...");
        fenInput.setPadding(dp(12), dp(10), dp(12), dp(10));

        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setColor(Color.argb(140, 8, 12, 20));
        inputBg.setCornerRadius(dp(14));
        inputBg.setStroke(dp(1), Color.argb(45, 255, 255, 255));
        fenInput.setBackground(inputBg);

        LinearLayout.LayoutParams ipParams = new LinearLayout.LayoutParams(-1, dp(72));
        ipParams.setMargins(0, dp(8), 0, dp(12));
        box.addView(fenInput, ipParams);

        Button analyze = new Button(this);
        analyze.setText("Buka & Analisis Posisi");
        analyze.setAllCaps(false);
        analyze.setTextColor(Color.rgb(4, 35, 28));
        analyze.setTextSize(13);
        analyze.setTypeface(Typeface.DEFAULT_BOLD);

        GradientDrawable btnBg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(110, 231, 183), Color.rgb(52, 211, 153)}
        );
        btnBg.setCornerRadius(dp(14));
        analyze.setBackground(btnBg);

        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(-1, dp(44));
        btnParams.setMargins(0, 0, 0, dp(8));
        box.addView(analyze, btnParams);

        analyze.setOnClickListener(v -> {
            String fen = fenInput.getText().toString().trim();
            if (fen.isEmpty()) {
                Toast.makeText(this, "Masukkan FEN terlebih dahulu", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent i = new Intent(this, MainActivity.class);
            i.putExtra("fen", fen);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        });

        Button close = new Button(this);
        close.setText("Tutup Floating");
        close.setAllCaps(false);
        close.setTextColor(Color.rgb(226, 232, 240));
        close.setTextSize(12);

        GradientDrawable closeBg = new GradientDrawable();
        closeBg.setColor(Color.argb(30, 255, 255, 255));
        closeBg.setCornerRadius(dp(14));
        closeBg.setStroke(dp(1), Color.argb(35, 255, 255, 255));
        close.setBackground(closeBg);

        LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(-1, dp(38));
        box.addView(close, closeParams);
        close.setOnClickListener(v -> stopSelf());

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        int flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;

        params = new WindowManager.LayoutParams(dp(305), WindowManager.LayoutParams.WRAP_CONTENT,
                type, flags, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = dp(12);
        params.y = getStatusBarHeight() + dp(12);

        panel = box;

        View.OnTouchListener dragListener = new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = params.x;
                    startY = params.y;
                    touchX = e.getRawX();
                    touchY = e.getRawY();
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int screenW = getResources().getDisplayMetrics().widthPixels;
                    int screenH = getResources().getDisplayMetrics().heightPixels;
                    int panelW = panel.getWidth() > 0 ? panel.getWidth() : dp(305);
                    int panelH = panel.getHeight() > 0 ? panel.getHeight() : dp(260);

                    int rawNewX = startX - (int)(e.getRawX() - touchX);
                    int rawNewY = startY + (int)(e.getRawY() - touchY);

                    int minX = dp(6);
                    int maxX = Math.max(minX, screenW - panelW - dp(6));
                    params.x = Math.max(minX, Math.min(maxX, rawNewX));

                    int minTop = getStatusBarHeight() + dp(6);
                    int maxBottom = Math.max(minTop, screenH - panelH - dp(12));
                    params.y = Math.max(minTop, Math.min(maxBottom, rawNewY));

                    windowManager.updateViewLayout(panel, params);
                    return true;
                }
                return e.getAction() == MotionEvent.ACTION_UP;
            }
        };

        header.setOnTouchListener(dragListener);
        grabber.setOnTouchListener(dragListener);

        windowManager.addView(panel, params);
    }

    @Override public void onDestroy() {
        if (windowManager != null && panel != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) { }
        }
        panel = null;
        super.onDestroy();
    }
}
