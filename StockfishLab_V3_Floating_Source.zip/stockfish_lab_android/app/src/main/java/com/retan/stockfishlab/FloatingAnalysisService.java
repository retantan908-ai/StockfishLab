package com.retan.stockfishlab;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Draggable floating FEN importer. It does not capture or inspect other apps' screens. */
public class FloatingAnalysisService extends Service {
    private WindowManager windowManager;
    private View panel;
    private WindowManager.LayoutParams params;
    private EditText fenInput;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            String channelId = "stockfish_floating";
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(channelId, "Stockfish floating window", NotificationManager.IMPORTANCE_LOW));
            Notification notification = new Notification.Builder(this, channelId)
                    .setSmallIcon(android.R.drawable.ic_menu_info_details)
                    .setContentTitle("StockfishLab floating aktif")
                    .setContentText("Masukkan FEN secara manual untuk analisis")
                    .setOngoing(true)
                    .build();
            startForeground(7301, notification);
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showPanel();
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void showPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(12));
        box.setBackgroundColor(Color.rgb(17, 27, 43));

        TextView title = new TextView(this);
        title.setText("♞ StockfishLab · Floating");
        title.setTextColor(Color.rgb(190, 239, 95));
        title.setTextSize(15);
        title.setPadding(0, 0, 0, dp(8));
        box.addView(title);

        TextView hint = new TextView(this);
        hint.setText("Tempel FEN posisi latihan / permainan yang sudah selesai:");
        hint.setTextColor(Color.WHITE);
        hint.setTextSize(11);
        box.addView(hint);

        fenInput = new EditText(this);
        fenInput.setText("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
        fenInput.setTextColor(Color.WHITE);
        fenInput.setTextSize(10);
        fenInput.setHintTextColor(Color.LTGRAY);
        fenInput.setHint("FEN");
        box.addView(fenInput, new LinearLayout.LayoutParams(-1, dp(74)));

        Button analyze = new Button(this);
        analyze.setText("Buka & analisis posisi ini");
        box.addView(analyze, new LinearLayout.LayoutParams(-1, dp(46)));
        analyze.setOnClickListener(v -> {
            String fen = fenInput.getText().toString().trim();
            if (fen.isEmpty()) { Toast.makeText(this, "Masukkan FEN terlebih dahulu", Toast.LENGTH_SHORT).show(); return; }
            Intent i = new Intent(this, MainActivity.class);
            i.putExtra("fen", fen);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        });

        Button close = new Button(this);
        close.setText("Tutup floating window");
        box.addView(close, new LinearLayout.LayoutParams(-1, dp(42)));
        close.setOnClickListener(v -> stopSelf());

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(dp(300), WindowManager.LayoutParams.WRAP_CONTENT,
                type, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = dp(12); params.y = dp(100);
        panel = box;
        title.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY; private float touchX, touchY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = params.x; startY = params.y; touchX = e.getRawX(); touchY = e.getRawY(); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x = startX - (int)(e.getRawX() - touchX);
                    params.y = startY + (int)(e.getRawY() - touchY);
                    windowManager.updateViewLayout(panel, params); return true;
                }
                return e.getAction() == MotionEvent.ACTION_UP;
            }
        });
        windowManager.addView(panel, params);
    }

    @Override public void onDestroy() {
        if (windowManager != null && panel != null) try { windowManager.removeView(panel); } catch (Exception ignored) { }
        panel = null;
        super.onDestroy();
    }
}
