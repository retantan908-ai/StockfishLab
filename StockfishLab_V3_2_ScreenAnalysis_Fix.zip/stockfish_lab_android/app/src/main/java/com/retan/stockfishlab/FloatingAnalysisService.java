package com.retan.stockfishlab;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.Toast;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Floating chess analysis: capture layar, kenali posisi, analisis Stockfish lokal,
 * lalu tampilkan penanda langkah di atas papan.
 */
public class FloatingAnalysisService extends Service implements EngineHost.Listener {
    static final String ACTION_PROJECTION = "com.retan.stockfishlab.action.PROJECTION_RESULT";
    static final String EXTRA_CODE = "code";
    static final String EXTRA_DATA = "data";

    private static final int NOTIF_ID = 7301;
    private static final String CHANNEL_ID = "stockfish_floating";
    private static final int[] DEPTHS = {12, 16, 20};
    private static final long AUTO_INTERVAL_MS = 2000;
    private static final int PENDING_NONE = 0, PENDING_ANALYZE = 1, PENDING_CALIBRATE = 2, PENDING_AUTO = 3;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();

    private WindowManager windowManager;
    private View panel, bubble, moveOverlay;
    private WindowManager.LayoutParams params;
    private TextView resultTitle, resultSub;
    private Button autoBtn, turnBtn, depthBtn;

    private ScreenCapture capture;
    private EngineHost engine;
    private SharedPreferences prefs;
    private BoardRecognizer.Calibration cal;
    private final PositionTracker tracker = new PositionTracker();
    private BoardRecognizer.Board cachedBoard;   // hanya dipakai di exec thread
    private float[] boardFrac;                   // posisi papan relatif terhadap layar
    private String bestMoveUci;
    private boolean screenWhiteAtBottom = true;

    private volatile boolean busy;
    private boolean panelExpandedBeforeCapture;
    private boolean auto;
    private int pending = PENDING_NONE;
    private int depthIdx = 1;
    private int turnMode = PositionTracker.TURN_AUTO;

    private String lastFen;
    private char[] lastCanon;
    private int currentJob;
    private char jobTurn = 'w';
    private boolean turnGuessed;
    private long noBoardUntil;
    private int infoDepth; private String infoKind, infoPv; private int infoValue;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("sf_screen", MODE_PRIVATE);
        cal = BoardRecognizer.Calibration.parse(prefs.getString("cal", null));
        depthIdx = Math.max(0, Math.min(DEPTHS.length - 1, prefs.getInt("depthIdx", 1)));
        turnMode = prefs.getInt("turnMode", PositionTracker.TURN_AUTO);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "Stockfish floating window", NotificationManager.IMPORTANCE_LOW));
            Notification n = buildNotification("Analisis papan catur di layar");
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST);
            else startForeground(NOTIF_ID, n);
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showPanel();
    }

    private Notification buildNotification(String text) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentTitle("StockfishLab floating aktif")
                .setContentText(text)
                .setOngoing(true)
                .build();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_PROJECTION.equals(intent.getAction())) {
            int code = intent.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED);
            Intent data = Build.VERSION.SDK_INT >= 33 ? intent.getParcelableExtra(EXTRA_DATA, Intent.class)
                    : (Intent) intent.getParcelableExtra(EXTRA_DATA);
            handleProjection(code, data);
        }
        return START_NOT_STICKY;
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private int getStatusBarHeight() {
        int resId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resId > 0) return getResources().getDimensionPixelSize(resId);
        return dp(28);
    }

    // ------------------------------------------------------------------ UI

    private Button glassButton(String text, boolean primary, int heightDp) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(dp(6), 0, dp(6), 0);
        b.setMinHeight(0); b.setMinimumHeight(0); b.setMinWidth(0); b.setMinimumWidth(0);
        GradientDrawable bg;
        if (primary) {
            bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Color.rgb(110, 231, 183), Color.rgb(52, 211, 153)});
            b.setTextColor(Color.rgb(4, 35, 28));
        } else {
            bg = new GradientDrawable();
            bg.setColor(Color.argb(30, 255, 255, 255));
            bg.setStroke(dp(1), Color.argb(35, 255, 255, 255));
            b.setTextColor(Color.rgb(226, 232, 240));
        }
        bg.setCornerRadius(dp(14));
        b.setBackground(bg);
        return b;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private void addPair(LinearLayout parent, Button a, Button b, int heightDp) {
        LinearLayout r = row();
        LinearLayout.LayoutParams la = new LinearLayout.LayoutParams(0, dp(heightDp), 1f);
        la.setMargins(0, 0, dp(3), 0);
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(0, dp(heightDp), 1f);
        lb.setMargins(dp(3), 0, 0, 0);
        r.addView(a, la); r.addView(b, lb);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(6));
        parent.addView(r, lp);
    }

    private void showPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(12), dp(16), dp(14));

        // iOS Dark Liquid Glass container
        GradientDrawable glassBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.argb(235, 22, 30, 46), Color.argb(225, 11, 16, 26)}
        );
        glassBg.setCornerRadius(dp(26));
        glassBg.setStroke(dp(1), Color.argb(65, 255, 255, 255));
        box.setBackground(glassBg);
        box.setElevation(dp(24));

        // iOS Pill Grabber Handle
        View grabber = new View(this);
        GradientDrawable grabberBg = new GradientDrawable();
        grabberBg.setColor(Color.argb(90, 255, 255, 255));
        grabberBg.setCornerRadius(dp(4));
        grabber.setBackground(grabberBg);
        LinearLayout.LayoutParams grabParams = new LinearLayout.LayoutParams(dp(38), dp(4));
        grabParams.gravity = Gravity.CENTER_HORIZONTAL;
        grabParams.setMargins(0, 0, 0, dp(10));
        box.addView(grabber, grabParams);

        // Header bar (Draggable area)
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(8));

        TextView title = new TextView(this);
        title.setText("♞ Stockfish Lab");
        title.setTextColor(Color.rgb(52, 211, 153));
        title.setTextSize(15);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView badge = new TextView(this);
        badge.setText("GLASS");
        badge.setTextColor(Color.argb(200, 255, 255, 255));
        badge.setTextSize(9);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setPadding(dp(8), dp(3), dp(8), dp(3));
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(Color.argb(35, 255, 255, 255));
        badgeBg.setCornerRadius(dp(99));
        badgeBg.setStroke(dp(1), Color.argb(40, 255, 255, 255));
        badge.setBackground(badgeBg);
        header.addView(badge);
        box.addView(header);

        // ---- Analisis layar
        Button screenBtn = glassButton("📷 Analisis Layar", true, 40);
        autoBtn = glassButton("", false, 40);
        addPair(box, screenBtn, autoBtn, 40);

        Button calBtn = glassButton("Kalibrasi posisi awal", false, 34);
        turnBtn = glassButton("", false, 34);
        addPair(box, calBtn, turnBtn, 34);

        depthBtn = glassButton("", false, 30);
        LinearLayout.LayoutParams dpP = new LinearLayout.LayoutParams(-1, dp(30));
        dpP.setMargins(0, 0, 0, dp(8));
        box.addView(depthBtn, dpP);

        // kartu hasil
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.argb(140, 8, 12, 20));
        cardBg.setCornerRadius(dp(14));
        cardBg.setStroke(dp(1), Color.argb(45, 255, 255, 255));
        card.setBackground(cardBg);

        resultTitle = new TextView(this);
        resultTitle.setTextColor(Color.rgb(110, 231, 183));
        resultTitle.setTextSize(15);
        resultTitle.setTypeface(Typeface.DEFAULT_BOLD);
        resultTitle.setText("Analisis layar siap");
        card.addView(resultTitle);

        resultSub = new TextView(this);
        resultSub.setTextColor(Color.rgb(165, 180, 200));
        resultSub.setTextSize(11);
        resultSub.setText("Buka papan catur, tekan Analisis Layar, atau aktifkan Auto. Petunjuk langkah terbaik akan dilingkari langsung di atas papan.");
        card.addView(resultSub);

        TextView fair = new TextView(this);
        fair.setTextColor(Color.argb(150, 165, 180, 200));
        fair.setTextSize(10);
        fair.setText("Untuk belajar & review. Jangan dipakai pada partai online yang sedang berjalan.");
        fair.setPadding(0, dp(4), 0, 0);
        card.addView(fair);

        LinearLayout.LayoutParams cardP = new LinearLayout.LayoutParams(-1, -2);
        cardP.setMargins(0, 0, 0, dp(10));
        box.addView(card, cardP);

        // Pengatur lebar panel
        TextView sizeLabel = new TextView(this);
        sizeLabel.setText("Ukuran panel");
        sizeLabel.setTextColor(Color.rgb(165, 180, 200));
        sizeLabel.setTextSize(11);
        box.addView(sizeLabel);
        SeekBar sizeBar = new SeekBar(this);
        sizeBar.setMax(130);
        sizeBar.setProgress(75);
        box.addView(sizeBar, new LinearLayout.LayoutParams(-1, dp(30)));
        sizeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && params != null && panel != null) {
                    params.width = dp(230 + progress);
                    try { windowManager.updateViewLayout(panel, params); } catch (Exception ignored) { }
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        Button minimize = glassButton("Minimalkan", false, 36);
        box.addView(minimize, new LinearLayout.LayoutParams(-1, dp(36)));
        minimize.setOnClickListener(v -> collapsePanel());
        Button close = glassButton("Tutup floating", false, 34);
        LinearLayout.LayoutParams closeP = new LinearLayout.LayoutParams(-1, dp(34));
        closeP.setMargins(0, dp(6), 0, 0);
        box.addView(close, closeP);
        close.setOnClickListener(v -> stopSelf());

        // ---- handler tombol analisis layar
        screenBtn.setOnClickListener(v -> requestAction(PENDING_ANALYZE));
        calBtn.setOnClickListener(v -> requestAction(PENDING_CALIBRATE));
        autoBtn.setOnClickListener(v -> {
            if (auto) setAuto(false); else requestAction(PENDING_AUTO);
        });
        turnBtn.setOnClickListener(v -> {
            turnMode = (turnMode + 1) % 3;
            prefs.edit().putInt("turnMode", turnMode).apply();
            exec.execute(tracker::reset);
            lastFen = null;
            refreshButtons();
        });
        depthBtn.setOnClickListener(v -> {
            depthIdx = (depthIdx + 1) % DEPTHS.length;
            prefs.edit().putInt("depthIdx", depthIdx).apply();
            lastFen = null;
            refreshButtons();
        });
        refreshButtons();

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        int flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;

        params = new WindowManager.LayoutParams(dp(305), WindowManager.LayoutParams.WRAP_CONTENT,
                type, flags, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = dp(12);
        params.y = getStatusBarHeight() + dp(12);

        panel = box;

        View.OnTouchListener dragListener = new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = params.x;
                    startY = params.y;
                    touchX = e.getRawX();
                    touchY = e.getRawY();
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int screenW = getResources().getDisplayMetrics().widthPixels;
                    int screenH = getResources().getDisplayMetrics().heightPixels;
                    int panelW = panel.getWidth() > 0 ? panel.getWidth() : dp(305);
                    int panelH = panel.getHeight() > 0 ? panel.getHeight() : dp(260);

                    int rawNewX = startX - (int)(e.getRawX() - touchX);
                    int rawNewY = startY + (int)(e.getRawY() - touchY);

                    int minX = dp(6);
                    int maxX = Math.max(minX, screenW - panelW - dp(6));
                    params.x = Math.max(minX, Math.min(maxX, rawNewX));

                    int minTop = getStatusBarHeight() + dp(6);
                    int maxBottom = Math.max(minTop, screenH - panelH - dp(12));
                    params.y = Math.max(minTop, Math.min(maxBottom, rawNewY));

                    windowManager.updateViewLayout(panel, params);
                    return true;
                }
                return e.getAction() == MotionEvent.ACTION_UP;
            }
        };

        header.setOnTouchListener(dragListener);
        grabber.setOnTouchListener(dragListener);

        windowManager.addView(panel, params);
        createBubble(type);
        createMoveOverlay(type);
        panel.setVisibility(View.GONE);
    }

    private void createBubble(int type) {
        TextView b = new TextView(this);
        b.setText("♞"); b.setTextColor(Color.rgb(5, 35, 28)); b.setTextSize(25);
        b.setTypeface(Typeface.DEFAULT_BOLD); b.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(110, 231, 183), Color.rgb(52, 211, 153)});
        bg.setShape(GradientDrawable.OVAL); bg.setStroke(dp(1), Color.argb(180,255,255,255));
        b.setBackground(bg); b.setElevation(dp(18));
        WindowManager.LayoutParams bp = new WindowManager.LayoutParams(dp(54), dp(54), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        bp.gravity=Gravity.TOP|Gravity.END; bp.x=dp(14); bp.y=getStatusBarHeight()+dp(18);
        b.setOnClickListener(v -> expandPanel());
        bubble=b; windowManager.addView(bubble,bp);
    }

    private void expandPanel() {
        if (bubble != null) bubble.setVisibility(View.GONE);
        if (panel != null) panel.setVisibility(View.VISIBLE);
    }
    private void collapsePanel() {
        if (panel != null) panel.setVisibility(View.GONE);
        if (bubble != null) bubble.setVisibility(View.VISIBLE);
    }

    private void createMoveOverlay(int type) {
        moveOverlay = new View(this) {
            final Paint paint = new Paint(3);
            @Override protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);
                if (boardFrac == null || bestMoveUci == null || bestMoveUci.length() < 4) return;
                float boardSize = getWidth() * boardFrac[2];
                float left = getWidth() * boardFrac[0], top = getHeight() * boardFrac[1];
                float cell = boardSize / 8f;
                paint.setStyle(Paint.Style.FILL); paint.setColor(Color.argb(48, 16, 220, 135));
                for (int n=0;n<2;n++) {
                    int file=bestMoveUci.charAt(n*2)-'a', rank=bestMoveUci.charAt(n*2+1)-'1';
                    if(file<0||file>7||rank<0||rank>7) continue;
                    if (!screenWhiteAtBottom) { file=7-file; rank=7-rank; }
                    float cx=left+(file+.5f)*cell, cy=top+(7-rank+.5f)*cell;
                    canvas.drawCircle(cx,cy,cell*.34f,paint);
                    paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(4));
                    paint.setColor(Color.argb(235,16,220,135)); canvas.drawCircle(cx,cy,cell*.34f,paint);
                    paint.setStyle(Paint.Style.FILL); paint.setColor(Color.argb(48,16,220,135));
                }
            }
        };
        WindowManager.LayoutParams op = new WindowManager.LayoutParams(-1,-1,type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        op.gravity=Gravity.TOP|Gravity.START;
        windowManager.addView(moveOverlay,op);
    }


    private void refreshButtons() {
        autoBtn.setText(auto ? "Auto: HIDUP" : "Auto: MATI");
        autoBtn.setTextColor(auto ? Color.rgb(110, 231, 183) : Color.rgb(226, 232, 240));
        String[] t = {"Giliran: Auto", "Giliran: Putih", "Giliran: Hitam"};
        turnBtn.setText(t[turnMode]);
        depthBtn.setText("Kedalaman: " + DEPTHS[depthIdx] + "  (ketuk untuk ganti)");
    }

    private void show(String title, String sub) {
        main.post(() -> {
            if (resultTitle == null) return;
            resultTitle.setText(title);
            resultSub.setText(sub == null ? "" : sub);
        });
    }

    private void toast(String msg) { main.post(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()); }

    // ------------------------------------------------------------------ izin & aksi

    private void requestAction(int action) {
        if (capture != null) { runAction(action); return; }
        pending = action;
        show("Menunggu izin…", "Pilih \"Seluruh layar\" pada dialog izin tangkap layar.");
        try {
            Intent i = new Intent(this, ScreenCaptureActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(i);
        } catch (Exception e) {
            pending = PENDING_NONE;
            show("Tidak bisa meminta izin", e.getMessage());
        }
    }

    private void runAction(int action) {
        if (action == PENDING_ANALYZE) runCapture(false, true);
        else if (action == PENDING_CALIBRATE) runCapture(true, true);
        else if (action == PENDING_AUTO) setAuto(true);
    }

    private void handleProjection(int code, Intent data) {
        int todo = pending; pending = PENDING_NONE;
        if (code != Activity.RESULT_OK || data == null) {
            show("Izin tangkap layar ditolak", "Tanpa izin ini, analisis layar tidak bisa berjalan.");
            return;
        }
        try {
            // Android 14+: tipe mediaProjection baru boleh dipakai setelah izin diberikan
            if (Build.VERSION.SDK_INT >= 29) {
                int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
                if (Build.VERSION.SDK_INT >= 34) types |= ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
                startForeground(NOTIF_ID, buildNotification("Analisis layar aktif"), types);
            }
        } catch (Exception e) {
            show("Gagal memulai layanan tangkap layar", e.getMessage());
            return;
        }
        if (capture != null) capture.release();
        capture = new ScreenCapture(this, code, data, () -> main.post(this::onCaptureStopped));
        if (!capture.start()) {
            capture = null;
            show("Gagal memulai tangkap layar", "Coba lagi, dan pilih \"Seluruh layar\".");
            return;
        }
        show("Tangkap layar aktif", "Memulai analisis…");
        final int action = todo;
        main.postDelayed(() -> { if (action != PENDING_NONE) runAction(action); else show("Tangkap layar aktif", "Tekan Analisis Layar."); }, 700);
    }

    private void onCaptureStopped() {
        capture = null;
        cachedBoard = null;
        setAuto(false);
        show("Tangkap layar dihentikan", "Tekan Analisis Layar untuk memberi izin lagi.");
    }

    private void setAuto(boolean on) {
        auto = on && capture != null;
        refreshButtons();
        main.removeCallbacks(autoTick);
        if (auto) {
            lastFen = null;
            main.post(autoTick);
        }
    }

    private final Runnable autoTick = new Runnable() {
        @Override public void run() {
            if (!auto) return;
            if (!busy && capture != null) runCapture(false, false);
            main.postDelayed(this, AUTO_INTERVAL_MS);
        }
    };

    // ------------------------------------------------------------------ tangkap + kenali

    private void runCapture(boolean calibrate, boolean manual) {
        if (busy || capture == null) return;
        busy = true;
        final ScreenCapture cap = capture;
        final boolean hide = true; // sembunyikan semua overlay sebelum screenshot agar papan tidak tertutup
        final String calFen = BoardRecognizer.START_PLACEMENT + " w KQkq - 0 1";
        if (manual) show("Menganalisis layar…", null);
        panelExpandedBeforeCapture = panel != null && panel.getVisibility() == View.VISIBLE;
        if (panel != null) panel.setVisibility(View.INVISIBLE);
        if (bubble != null) bubble.setVisibility(View.INVISIBLE);
        if (moveOverlay != null) moveOverlay.setVisibility(View.INVISIBLE);
        exec.execute(() -> {
            try {
                if (hide) {
                    // beri waktu agar semua overlay benar-benar hilang dari frame yang ditangkap
                    try { Thread.sleep(200); } catch (InterruptedException ignored) { }
                }
                BoardRecognizer.Img im = cap.grab();
                main.post(this::restoreFloatingUi);
                if (im == null) { if (manual) show("Belum ada gambar layar", "Coba lagi sebentar lagi."); return; }
                process(im, calibrate, manual, calFen);
            } catch (Throwable t) {
                main.post(this::restoreFloatingUi);
                show("Gagal menganalisis layar", String.valueOf(t.getMessage()));
            } finally {
                busy = false;
            }
        });
    }

    private void restoreFloatingUi() {
        if (panel != null) panel.setVisibility(panelExpandedBeforeCapture ? View.VISIBLE : View.GONE);
        if (bubble != null) bubble.setVisibility(panelExpandedBeforeCapture ? View.GONE : View.VISIBLE);
        if (moveOverlay != null) moveOverlay.setVisibility(View.VISIBLE);
    }

    private void process(BoardRecognizer.Img im, boolean calibrate, boolean manual, String calFen) {
        BoardRecognizer.Board bd = BoardRecognizer.verify(im, cachedBoard);
        if (bd == null && !manual && System.currentTimeMillis() < noBoardUntil) return;   // hemat baterai saat papan tak ada
        if (bd == null) bd = BoardRecognizer.findBoard(im);
        noBoardUntil = bd == null ? System.currentTimeMillis() + 6000 : 0;
        cachedBoard = bd;
        if (bd == null) {
            boardFrac = null;
            if (manual || auto) show("Papan tidak ditemukan", "Pastikan seluruh papan terlihat di layar. Panel otomatis disembunyikan saat pemindaian.");
            return;
        }
        boardFrac = new float[]{bd.x / (float) im.w, bd.y / (float) im.h, bd.size / (float) im.w, bd.size / (float) im.h};
        BoardRecognizer.Frame fr = BoardRecognizer.extract(im, bd);

        if (calibrate) {
            String placement = calFen.split("\\s+")[0];
            String[] err = new String[1];
            int n = BoardRecognizer.calibrate(fr, placement, cal, err);
            if (n < 0) { show("Kalibrasi gagal", err[0]); return; }
            prefs.edit().putString("cal", cal.serialize()).apply();
            lastFen = null; tracker.reset();
            show("Kalibrasi tersimpan", "Dipelajari " + n + " jenis bidak (total " + cal.count() + "/12)."
                    + (cal.complete() ? " Siap dipakai." : " Kalibrasi lagi dengan posisi yang memuat bidak lainnya."));
            return;
        }

        if (!cal.complete()) {
            if (BoardRecognizer.looksLikeStart(fr)) {
                String[] err = new String[1];
                int n = BoardRecognizer.calibrate(fr, BoardRecognizer.START_PLACEMENT, cal, err);
                if (n > 0) prefs.edit().putString("cal", cal.serialize()).apply();
            }
            if (!cal.complete()) {
                show("Perlu kalibrasi", "Tampilkan posisi awal catur di layar lalu tekan Kalibrasi. "
                        + "Gunakan posisi awal lengkap agar semua jenis bidak dapat dipelajari.");
                return;
            }
        }

        BoardRecognizer.Result r = BoardRecognizer.recognize(fr, cal);
        if (!r.ok) {
            if (manual || auto) show("Posisi belum terbaca", r.error + (r.rejected > 0 ? " (" + r.rejected + " kotak tidak dikenali)" : ""));
            return;
        }
        String fen = tracker.update(r.canon, turnMode, r.moverGuess);
        turnGuessed = tracker.turnWasGuessed() && turnMode == PositionTracker.TURN_AUTO;
        if (!manual && fen.equals(lastFen)) return;   // mode auto: posisi tidak berubah
        lastFen = fen;
        bestMoveUci = null;
        if (moveOverlay != null) main.post(moveOverlay::invalidate);
        lastCanon = r.canon;
        screenWhiteAtBottom = r.whiteAtBottom;
        jobTurn = tracker.turn();
        final int conf = Math.round(r.confidence * 100);
        main.post(() -> {
            ensureEngine();
            show("Menghitung…", "Giliran " + (jobTurn == 'w' ? "Putih" : "Hitam") + (turnGuessed ? " (tebakan — ubah lewat tombol Giliran)" : "")
                    + " · keyakinan " + conf + "%" + (engine.isReady() ? "" : " · memuat Stockfish…"));
            infoPv = null; infoKind = null;
            currentJob = engine.analyze(lastFen, DEPTHS[depthIdx], 1);
        });
    }

    // ------------------------------------------------------------------ engine

    private void ensureEngine() {
        if (engine == null) { engine = new EngineHost(this, this); engine.start(); }
    }

    @Override public void onReady() { }

    @Override public void onInfo(int id, int depth, String kind, int value, String pv) {
        if (id != currentJob) return;
        infoDepth = depth; infoKind = kind; infoValue = value; infoPv = pv;
        showResult(depth, kind, value, pv, false);
    }

    @Override public void onBest(int id, String move) {
        if (id != currentJob) return;
        if ("(none)".equals(move) || "0000".equals(move)) { show("Tidak ada langkah legal", "Posisi ini sudah berakhir (skakmat/remis)."); return; }
        bestMoveUci = move;
        if (moveOverlay != null) main.post(moveOverlay::invalidate);
        if (infoPv != null && infoPv.startsWith(move)) showResult(infoDepth, infoKind, infoValue, infoPv, true);
        else showResult(DEPTHS[depthIdx], null, 0, move, true);
    }

    @Override public void onError(String message) {
        show("Engine bermasalah", message);
    }

    private void showResult(int depth, String kind, int value, String pv, boolean done) {
        String[] moves = pv.trim().split("\\s+");
        String first = moves[0];
        String evalText = "";
        if (kind != null) {
            int white = jobTurn == 'w' ? value : -value;
            if ("mate".equals(kind)) evalText = (white > 0 ? "+" : "-") + "M" + Math.abs(white);
            else evalText = String.format(Locale.US, "%+.2f", white / 100.0);
        }
        String title = describeMove(first) + (evalText.isEmpty() ? "" : "   " + evalText);
        StringBuilder sub = new StringBuilder();
        sub.append(done ? "Selesai" : "Menghitung").append(" · kedalaman ").append(depth)
                .append(" · giliran ").append(jobTurn == 'w' ? "Putih" : "Hitam");
        if (turnGuessed) sub.append(" (tebakan)");
        if (moves.length > 1) {
            sub.append("\nRangkaian: ");
            for (int i = 0; i < Math.min(5, moves.length); i++) sub.append(moves[i]).append(' ');
        }
        show(title, sub.toString());
    }

    /** "♘ g1 → f3", "O-O", "♙ e7 → e8 =Q". */
    private String describeMove(String uci) {
        if (uci == null || uci.length() < 4 || lastCanon == null) return String.valueOf(uci);
        int ff = uci.charAt(0) - 'a', fr = uci.charAt(1) - '1', tf = uci.charAt(2) - 'a', tr = uci.charAt(3) - '1';
        if (ff < 0 || ff > 7 || tf < 0 || tf > 7 || fr < 0 || fr > 7 || tr < 0 || tr > 7) return uci;
        char p = lastCanon[(7 - fr) * 8 + ff];
        String from = uci.substring(0, 2), to = uci.substring(2, 4);
        if ((p == 'K' || p == 'k') && Math.abs(tf - ff) == 2) return tf > ff ? "O-O" : "O-O-O";
        int gi = "KQRBNPkqrbnp".indexOf(p);
        String glyph = gi >= 0 ? "♔♕♖♗♘♙♚♛♜♝♞♟".substring(gi, gi + 1) : "";
        String promo = uci.length() > 4 ? " =" + Character.toUpperCase(uci.charAt(4)) : "";
        return glyph + " " + from + " → " + to + promo;
    }

    // ------------------------------------------------------------------ siklus hidup

    @Override public void onDestroy() {
        auto = false;
        main.removeCallbacksAndMessages(null);
        exec.shutdownNow();
        if (capture != null) { capture.release(); capture = null; }
        if (engine != null) { engine.destroy(); engine = null; }
        if (windowManager != null && panel != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) { }
        }
        panel = null;
        if (windowManager != null) {
            if (bubble != null) try { windowManager.removeView(bubble); } catch (Exception ignored) { }
            if (moveOverlay != null) try { windowManager.removeView(moveOverlay); } catch (Exception ignored) { }
        }
        bubble = null; moveOverlay = null;
        super.onDestroy();
    }
}
