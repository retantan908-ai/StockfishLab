package com.retan.stockfishlab;

import java.util.Arrays;

/**
 * Melengkapi penempatan bidak hasil pengenalan layar menjadi FEN lengkap:
 * giliran main, hak rokade, dan en passant. Semuanya diperkirakan dari urutan tangkapan layar.
 */
public final class PositionTracker {
    public static final int TURN_AUTO = 0, TURN_WHITE = 1, TURN_BLACK = 2;

    private char[] prev;
    private char turn = 'w';
    private boolean turnKnown = false;
    private boolean cK, cQ, ck, cq;
    private boolean castleInit = false;
    private String ep = "-";

    public char turn() { return turn; }
    public boolean turnWasGuessed() { return !turnKnown; }
    public void reset() { prev = null; turnKnown = false; turn = 'w'; castleInit = false; ep = "-"; }

    /** @param canon 64 karakter urutan FEN (a8..h1), ' ' = kosong. */
    public String update(char[] canon, int manualTurn, char highlightMover) {
        char[] cur = canon.clone();
        String placement = BoardRecognizer.placementOf(cur);
        boolean isStart = placement.equals(BoardRecognizer.START_PLACEMENT);
        if (isStart) { castleInit = false; prev = null; turnKnown = false; ep = "-"; }

        // hak rokade: awalnya dari posisi bidak, setelah itu hanya bisa hilang
        boolean kHome = cur[60] == 'K', Kr = cur[63] == 'R', Qr = cur[56] == 'R';
        boolean khome = cur[4] == 'k', kr = cur[7] == 'r', qr = cur[0] == 'r';
        if (!castleInit) { cK = kHome && Kr; cQ = kHome && Qr; ck = khome && kr; cq = khome && qr; castleInit = true; }
        else { cK &= kHome && Kr; cQ &= kHome && Qr; ck &= khome && kr; cq &= khome && qr; }

        char moverNow = 0;
        if (prev != null && !Arrays.equals(prev, cur)) {
            ep = "-";
            boolean white = false, black = false; int arrivedCount = 0; int arrivedIdx = -1, departedIdx = -1, departed = 0;
            for (int i = 0; i < 64; i++) {
                if (cur[i] != ' ' && cur[i] != prev[i]) {
                    arrivedCount++; arrivedIdx = i;
                    if (Character.isUpperCase(cur[i])) white = true; else black = true;
                }
                if (prev[i] != ' ' && cur[i] == ' ') { departed++; departedIdx = i; }
            }
            if (white != black) moverNow = white ? 'w' : 'b';
            // en passant: satu pion melangkah dua kotak
            if (arrivedCount == 1 && departed == 1 && (cur[arrivedIdx] == 'P' || cur[arrivedIdx] == 'p')
                    && prev[departedIdx] == cur[arrivedIdx] && arrivedIdx % 8 == departedIdx % 8
                    && Math.abs(arrivedIdx - departedIdx) == 16) {
                int mid = (arrivedIdx + departedIdx) / 2;
                char enemy = cur[arrivedIdx] == 'P' ? 'p' : 'P';
                int f = arrivedIdx % 8;
                boolean canCap = (f > 0 && cur[arrivedIdx - 1] == enemy) || (f < 7 && cur[arrivedIdx + 1] == enemy);
                if (canCap) ep = "" + (char) ('a' + mid % 8) + (8 - mid / 8);
            }
        }
        if (manualTurn == TURN_WHITE) { turn = 'w'; turnKnown = true; }
        else if (manualTurn == TURN_BLACK) { turn = 'b'; turnKnown = true; }
        else if (isStart) { turn = 'w'; turnKnown = true; }
        else if (moverNow != 0) { turn = moverNow == 'w' ? 'b' : 'w'; turnKnown = true; }
        else if (!turnKnown && highlightMover != 0) { turn = highlightMover == 'w' ? 'b' : 'w'; turnKnown = true; }
        prev = cur;

        String castle = "" + (cK ? "K" : "") + (cQ ? "Q" : "") + (ck ? "k" : "") + (cq ? "q" : "");
        if (castle.isEmpty()) castle = "-";
        return placement + " " + turn + " " + castle + " " + ep + " 0 1";
    }
}
