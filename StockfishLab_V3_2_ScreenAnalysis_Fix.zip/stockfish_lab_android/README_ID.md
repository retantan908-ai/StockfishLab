# Stockfish Lab V2.2 — Proyek Android + Website Static

Stockfish Lab V2.2 adalah aplikasi analisis catur yang memakai Android WebView, HTML/CSS/JavaScript, chess.js 1.4.0 untuk aturan catur, dan Stockfish.js 19.0.1 Lite single-threaded untuk analisis.

## Perbaikan V2.2

- Memperbaiki halaman blank: tersedia papan awal sebagai fallback visual, sedangkan bundle interaktif `assets/main.js` dibuat saat build.
- Menambahkan pesan error yang jelas jika `main.js` tidak ter-deploy.
- Menambahkan timeout inisialisasi engine, penanganan `Worker.onerror`/`messageerror`, dan tombol coba ulang engine.
- Build workflow menghasilkan dua paket berbeda: APK Android dan website static untuk EdgeOne.
- Engine dan aturan catur dibundel lokal; tidak ada download engine dari CDN ketika halaman dibuka.

## Fitur

- Papan interaktif dengan pilih-bidak lalu kotak tujuan, atau drag-and-drop.
- Legal move validation termasuk rokade, en passant, promosi, skak, dan skakmat.
- Pilihan orientasi putih/hitam di bawah.
- Analisis otomatis setelah langkah atau analisis manual.
- Langkah terbaik, evaluasi, depth, waktu, dan hingga 5 variasi.
- Terapkan langkah terbaik untuk meninjau posisi, Undo, Redo, Reset, riwayat, dan input FEN.

## Build melalui GitHub Actions

ZIP ini adalah source project; ZIP ini bukan paket website siap unggah. Upload `StockfishLab_Android_Project_V2_2.zip` ke root repository, lalu ganti `.github/workflows/build.yml` dengan file `StockfishLab_V2_2_build.yml` yang disediakan terpisah. Commit changes.

Workflow membundel `main-entry.js` + chess.js menjadi `assets/main.js`, mengambil file Stockfish JS/WASM, mengompilasi APK, dan membuat folder website siap deploy.

## Deploy website ke EdgeOne

Dari GitHub Actions, unduh artifact `StockfishLab-Web-Dist`, ekstrak, lalu upload seluruh ISI folder hasil ekstrak ke root static website. Struktur harus dipertahankan:

- `index.html`
- `assets/main.js`
- `engine/stockfish-19-lite-single.js`
- `engine/stockfish-19-lite-single.wasm`

Jangan upload ZIP source Android mentah ke EdgeOne. Pastikan file `.wasm` disajikan dengan MIME `application/wasm`.

## Install APK

Unduh artifact `StockfishLab-V2.2-APK` dari workflow yang berhasil. Ekstrak artifact dan install `app-debug.apk`. Jika Android melaporkan konflik tanda tangan, uninstall versi lama dahulu.

## Versi dan lisensi

- versionCode: 3
- versionName: 2.2
- Minimum Android: API 24
- Stockfish.js 19.0.1: GPL-3.0
- chess.js 1.4.0: BSD-2-Clause

Lihat `THIRD_PARTY_NOTICES.txt`.


## StockfishLab V2.3 — perbaikan papan dan analisis otomatis

- Papan dirender terpisah dari proses startup engine, sehingga kegagalan engine tidak mengosongkan papan.
- `main-entry.js` harus dibundle bersama `chess.js` menjadi `assets/main.js` oleh workflow.
- Engine Stockfish 19 Lite single-threaded dan file WASM disalin ke `assets/engine/` saat workflow berjalan.
- Untuk website EdgeOne, deploy isi artifact `StockfishLab-Web-Dist` ke root hosting; jangan deploy ZIP source Android mentah.
- Untuk Android, instal artifact APK dari workflow setelah build sukses.
- Auto-analysis aktif secara default: analisis posisi awal setelah engine siap dan analisis ulang setelah setiap langkah legal.

Build perlu diuji melalui GitHub Actions dan browser/HP setelah deploy.


## V3.1 — Analisis Layar otomatis di Floating Mode

Panel floating kini punya tombol **📷 Analisis Layar**: aplikasi menangkap layar, menemukan papan catur, mengenali bidak, lalu Stockfish lokal menghitung langkah terbaik dan menampilkannya langsung di panel (tanpa membuka aplikasi utama).

**Cara pakai**
1. Buka Float Mode, tekan **📷 Analisis Layar**, setujui dialog izin tangkap layar (pilih **Seluruh layar**).
2. Kalibrasi pertama: tampilkan **posisi awal** catur di layar (aplikasi/situs apa pun). Kalibrasi berjalan otomatis jika posisi awal terdeteksi. Jika kalibrasi belum pernah dilakukan dan layar bukan posisi awal, isi kolom FEN dengan posisi yang sedang tampil lalu tekan **Kalibrasi**. Template tersimpan; ulangi hanya jika tema/set bidak berganti.
3. **Auto: HIDUP** menganalisis ulang tiap 2 detik hanya ketika posisi berubah. Panel disembunyikan sesaat saat menimpa papan agar tidak ikut terbaca; geser panel keluar papan agar tidak berkedip.
4. Ketuk kartu hasil untuk memasukkan FEN terakhir ke kolom, lalu **Buka & Analisis Posisi** untuk memeriksanya di papan utama.

**Yang diperkirakan otomatis** (tombol *Giliran* untuk memaksa Putih/Hitam)
- Giliran main: dari perubahan posisi antar-tangkapan, atau dari sorotan langkah terakhir pada tangkapan pertama (ditandai "tebakan").
- Hak rokade: dari posisi raja/benteng pada tangkapan pertama, lalu hanya bisa hilang. En passant: dari langkah pion dua kotak yang terlihat.
- Orientasi papan (putih di bawah/atas) terdeteksi sendiri.

**Batasan**
- Pengenalan bergantung pada kalibrasi set bidak yang sama; animasi bidak, panah/petunjuk langkah tebal di atas bidak, atau papan yang terpotong bisa menggagalkan pembacaan (pesan akan muncul).
- Android hanya mengizinkan tangkap layar dengan izin pengguna; layanan berhenti jika izin dicabut dari status bar.
- Gunakan untuk belajar dan review. Jangan dipakai pada partai online yang sedang berjalan; hal itu melanggar aturan fair play hampir semua situs catur.

Modul pengenalan (`BoardRecognizer`, `PositionTracker`) murni Java dan sudah diuji pada papan sintetis (4 tema, papan terbalik, sorotan langkah, titik petunjuk, ukuran berbeda). Alur Android (MediaProjection, WebView engine di latar) perlu dicoba di perangkat nyata setelah build GitHub Actions.

## Perubahan V3.2 (Floating Screen Analysis)
- Floating dibuka sebagai gelembung bulat kecil; ketuk untuk membuka panel.
- Panel memiliki pengatur lebar dan tombol Minimalkan/Tutup.
- Input FEN manual di panel dihapus; kalibrasi memakai posisi awal catur.
- Saat mengambil screenshot, panel, gelembung, dan lapisan petunjuk disembunyikan sementara agar tidak menutupi papan.
- Langkah terbaik ditandai dengan dua lingkaran langsung di atas kotak asal dan tujuan pada papan.
- Orientasi papan hitam-di-bawah juga diperhitungkan saat menggambar lingkaran.

Kalibrasi: tampilkan posisi awal lengkap (semua bidak pada posisi awal), buka panel, lalu tekan **Kalibrasi posisi awal** satu kali. Setelah itu gunakan **Analisis Layar** atau aktifkan **Auto**.
