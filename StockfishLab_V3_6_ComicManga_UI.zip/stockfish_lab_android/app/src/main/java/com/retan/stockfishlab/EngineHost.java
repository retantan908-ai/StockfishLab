package com.retan.stockfishlab;

import android.content.Context;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Stockfish tanpa UI: WebView tersembunyi (overlay 1x1 px) yang memuat assets/engine-host.html.
 * Overlay 1x1 menjaga WebView tetap "terlihat" sehingga Chromium tidak men-throttle timer/Worker
 * ketika aplikasi utama berada di belakang. Semua callback dikirim ke main thread.
 */
final class EngineHost {
    interface Listener {
        void onReady();
        void onInfo(int id, int depth, String kind, int value, String pv);
        void onBest(int id, String move);
        void onError(String message);
    }

    private final Context ctx;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private boolean ready;
    private int nextId = 1;
    private int qId; private String qFen; private int qDepth, qMulti;   // permintaan yang menunggu engine siap

    EngineHost(Context ctx, Listener listener) {
        this.ctx = ctx.getApplicationContext();
        this.listener = listener;
    }

    boolean isReady() { return ready; }

    void start() {
        if (web != null) return;
        web = new WebView(ctx);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        web.setAlpha(0f);
        web.addJavascriptInterface(new Bridge(), "Android");

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(ctx))
                .addPathHandler("/engine/", this::openEngineAsset)
                .build();
        web.setWebViewClient(new WebViewClientCompat() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return loader.shouldInterceptRequest(Uri.parse(url));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"appassets.androidplatform.net".equals(request.getUrl().getHost());
            }
        });

        try {
            WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(1, 1, type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            wm.addView(web, lp);
        } catch (Exception ignored) { /* tetap jalan tanpa overlay */ }

        web.loadUrl("https://appassets.androidplatform.net/assets/engine-host.html");
    }

    /** @return id permintaan; hasil dikirim lewat Listener. */
    int analyze(String fen, int depth, int multipv) {
        if (web == null) start();
        final int id = nextId++;
        main.post(() -> {
            if (!ready) { qId = id; qFen = fen; qDepth = depth; qMulti = multipv; return; }
            run(id, fen, depth, multipv);
        });
        return id;
    }

    private void run(int id, String fen, int depth, int multipv) {
        if (web == null) return;
        web.evaluateJavascript("SFHost.analyze(" + id + "," + JSONObject.quote(fen) + "," + depth + "," + multipv + ")", null);
    }

    void stop() {
        main.post(() -> { if (web != null) web.evaluateJavascript("window.SFHost&&SFHost.stop()", null); });
    }

    void destroy() {
        final WebView w = web;
        web = null; ready = false;
        if (w == null) return;
        try {
            WindowManager wm = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
            wm.removeView(w);
        } catch (Exception ignored) { }
        try { w.destroy(); } catch (Exception ignored) { }
    }

    private WebResourceResponse openEngineAsset(String path) {
        try {
            InputStream in = ctx.getAssets().open("engine/" + path);
            String mime = path.endsWith(".wasm") ? "application/wasm" : "text/javascript";
            return new WebResourceResponse(mime, null, in);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null,
                    new ByteArrayInputStream(new byte[0]));
        }
    }

    private final class Bridge {
        @JavascriptInterface public void onReady() {
            main.post(() -> {
                ready = true; listener.onReady();
                if (qFen != null) { String f = qFen; qFen = null; run(qId, f, qDepth, qMulti); }
            });
        }
        @JavascriptInterface public void onInfo(int id, int depth, String kind, int value, String pv) {
            main.post(() -> listener.onInfo(id, depth, kind, value, pv));
        }
        @JavascriptInterface public void onBest(int id, String move) { main.post(() -> listener.onBest(id, move)); }
        @JavascriptInterface public void onError(String message) { main.post(() -> listener.onError(message)); }
    }
}
