package com.retan.stockfishlab;

import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.nio.ByteBuffer;

/**
 * Tangkap layar lewat MediaProjection (izin diberikan pengguna lewat dialog sistem).
 * Frame terbaru disimpan dan baru dikonversi ke piksel saat diminta, jadi murah ketika layar bergerak.
 * Resolusi diperkecil (sisi pendek maks. 720 px) karena pengenalan papan tidak butuh lebih.
 */
final class ScreenCapture {
    interface StopListener { void onStopped(); }

    private final Context ctx;
    private final int resultCode;
    private final Intent data;
    private final StopListener stopListener;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler handler;
    private final Object lock = new Object();
    private Image last;
    private volatile long frames;
    private int w, h, dpi;
    private boolean released;

    ScreenCapture(Context ctx, int resultCode, Intent data, StopListener l) {
        this.ctx = ctx.getApplicationContext();
        this.resultCode = resultCode;
        this.data = data;
        this.stopListener = l;
    }

    long frameCount() { return frames; }

    private DisplayMetrics realMetrics() {
        DisplayMetrics m = new DisplayMetrics();
        ((WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(m);
        return m;
    }

    private void computeSize(DisplayMetrics m) {
        float sc = Math.min(1f, 720f / Math.min(m.widthPixels, m.heightPixels));
        w = Math.max(64, Math.round(m.widthPixels * sc));
        h = Math.max(64, Math.round(m.heightPixels * sc));
        dpi = m.densityDpi;
    }

    private void newReader() {
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3);
        reader.setOnImageAvailableListener(r -> {
            Image img;
            try { img = r.acquireLatestImage(); } catch (Exception e) { return; }
            if (img == null) return;
            synchronized (lock) {
                if (last != null) last.close();
                last = img;
                frames++;
                lock.notifyAll();
            }
        }, handler);
    }

    boolean start() {
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(resultCode, data);
            if (projection == null) return false;
            thread = new HandlerThread("sf-screen-capture");
            thread.start();
            handler = new Handler(thread.getLooper());
            // Android 14+: callback wajib didaftarkan sebelum createVirtualDisplay
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { release(); if (stopListener != null) stopListener.onStopped(); }
            }, handler);
            computeSize(realMetrics());
            newReader();
            display = projection.createVirtualDisplay("StockfishLabCapture", w, h, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
            return display != null;
        } catch (Exception e) {
            release();
            return false;
        }
    }

    /** Sesuaikan ukuran jika layar diputar (portrait <-> landscape). */
    private void ensureSize() {
        DisplayMetrics m = realMetrics();
        int oldW = w, oldH = h;
        computeSize(m);
        if (w == oldW && h == oldH) return;
        synchronized (lock) { if (last != null) { last.close(); last = null; } }
        ImageReader old = reader;
        newReader();
        if (display != null) { display.resize(w, h, dpi); display.setSurface(reader.getSurface()); }
        if (old != null) old.close();
    }

    /** Tunggu frame baru setelah overlay disembunyikan, agar frame lama tidak ikut dianalisis. */
    BoardRecognizer.Img grabAfter(long frameBeforeHide, long timeoutMs) {
        long deadline = SystemClock.uptimeMillis() + Math.max(100L, timeoutMs);
        synchronized (lock) {
            while (!released && (last == null || frames <= frameBeforeHide)) {
                long left = deadline - SystemClock.uptimeMillis();
                if (left <= 0) break;
                try { lock.wait(left); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
            }
            if (released || last == null || frames <= frameBeforeHide) return null;
        }
        return grab();
    }

    /** Ambil frame terbaru sebagai piksel ARGB; null jika belum ada frame. */
    BoardRecognizer.Img grab() {
        try {
            if (released) return null;
            Image img;
            synchronized (lock) {
                img = last;
                if (img == null) return null;
                int iw = img.getWidth(), ih = img.getHeight();
                Image.Plane plane = img.getPlanes()[0];
                ByteBuffer buf = plane.getBuffer().duplicate();
                int rowStride = plane.getRowStride();
                int[] px = new int[iw * ih];
                byte[] row = new byte[iw * 4];
                for (int y = 0; y < ih; y++) {
                    buf.position(y * rowStride);
                    buf.get(row, 0, iw * 4);
                    int o = y * iw;
                    for (int x = 0; x < iw; x++) {
                        int i = x * 4;
                        px[o + x] = 0xFF000000 | ((row[i] & 255) << 16) | ((row[i + 1] & 255) << 8) | (row[i + 2] & 255);
                    }
                }
                return new BoardRecognizer.Img(px, iw, ih);
            }
        } catch (Exception e) {
            return null;
        } finally {
            try { if (!released) ensureSize(); } catch (Exception ignored) { }
        }
    }

    void release() {
        if (released) return;
        released = true;
        try { if (display != null) display.release(); } catch (Exception ignored) { }
        synchronized (lock) {
            if (last != null) { last.close(); last = null; }
            lock.notifyAll();
        }
        try { if (reader != null) reader.close(); } catch (Exception ignored) { }
        try { if (projection != null) projection.stop(); } catch (Exception ignored) { }
        if (thread != null) thread.quitSafely();
    }
}
