package com.retan.stockfishlab;

import java.util.Arrays;

/**
 * Melengkapi penempatan bidak hasil pengenalan layar menjadi FEN lengkap:
 * giliran main, hak rokade, dan en passant. Semuanya diperkirakan dari urutan tangkapan layar.
 */
public final class PositionTracker {
    public static final int TURN_AUTO = 0, TURN_WHITE = 1, TURN_BLACK = 2;

    private char[] prev;
    private char turn = 'w';
    private boolean turnKnown = false;
    private boolean cK, cQ, ck, cq;
    private boolean castleInit = false;
    private String ep = "-";

    private String problem;
    public char turn() { return turn; }
    /** Null jika posisi masuk akal; selain itu alasan singkat (untuk ditampilkan). */
    public String problem() { return problem; }
    public boolean turnWasGuessed() { return !turnKnown; }
    public void reset() { prev = null; turnKnown = false; turn = 'w'; castleInit = false; ep = "-"; }

    /** @param canon 64 karakter urutan FEN (a8..h1), ' ' = kosong. */
    public String update(char[] canon, int manualTurn, char highlightMover) {
        char[] cur = canon.clone();
        String placement = BoardRecognizer.placementOf(cur);
        boolean isStart = placement.equals(BoardRecognizer.START_PLACEMENT);
        if (isStart) { castleInit = false; prev = null; turnKnown = false; ep = "-"; }

        // hak rokade: awalnya dari posisi bidak, setelah itu hanya bisa hilang
        boolean kHome = cur[60] == 'K', Kr = cur[63] == 'R', Qr = cur[56] == 'R';
        boolean khome = cur[4] == 'k', kr = cur[7] == 'r', qr = cur[0] == 'r';
        if (!castleInit) { cK = kHome && Kr; cQ = kHome && Qr; ck = khome && kr; cq = khome && qr; castleInit = true; }
        else { cK &= kHome && Kr; cQ &= kHome && Qr; ck &= khome && kr; cq &= khome && qr; }

        char moverNow = 0;
        if (prev != null && !Arrays.equals(prev, cur)) {
            ep = "-";
            boolean white = false, black = false; int arrivedCount = 0; int arrivedIdx = -1, departedIdx = -1, departed = 0;
            for (int i = 0; i < 64; i++) {
                if (cur[i] != ' ' && cur[i] != prev[i]) {
                    arrivedCount++; arrivedIdx = i;
                    if (Character.isUpperCase(cur[i])) white = true; else black = true;
                }
                if (prev[i] != ' ' && cur[i] == ' ') { departed++; departedIdx = i; }
            }
            if (white != black) moverNow = white ? 'w' : 'b';
            // en passant: satu pion melangkah dua kotak
            if (arrivedCount == 1 && departed == 1 && (cur[arrivedIdx] == 'P' || cur[arrivedIdx] == 'p')
                    && prev[departedIdx] == cur[arrivedIdx] && arrivedIdx % 8 == departedIdx % 8
                    && Math.abs(arrivedIdx - departedIdx) == 16) {
                int mid = (arrivedIdx + departedIdx) / 2;
                char enemy = cur[arrivedIdx] == 'P' ? 'p' : 'P';
                int f = arrivedIdx % 8;
                boolean canCap = (f > 0 && cur[arrivedIdx - 1] == enemy) || (f < 7 && cur[arrivedIdx + 1] == enemy);
                if (canCap) ep = "" + (char) ('a' + mid % 8) + (8 - mid / 8);
            }
        }
        if (manualTurn == TURN_WHITE) { turn = 'w'; turnKnown = true; }
        else if (manualTurn == TURN_BLACK) { turn = 'b'; turnKnown = true; }
        else if (isStart) { turn = 'w'; turnKnown = true; }
        else if (moverNow != 0) { turn = moverNow == 'w' ? 'b' : 'w'; turnKnown = true; }
        else if (!turnKnown && highlightMover != 0) { turn = highlightMover == 'w' ? 'b' : 'w'; turnKnown = true; }
        prev = cur;

        // legalitas: raja pihak yang TIDAK jalan tidak boleh sedang diskak. Pada mode Auto, balik giliran bila perlu.
        problem = sanity(cur);
        if (problem == null) {
            boolean wChk = kingAttacked(cur, true), bChk = kingAttacked(cur, false);
            if (wChk && bChk) problem = "Kedua raja sedang diskak (pembacaan bidak keliru).";
            else if ((turn == 'w' && bChk) || (turn == 'b' && wChk)) {
                if (manualTurn == TURN_AUTO) { turn = turn == 'w' ? 'b' : 'w'; turnKnown = true; }
                else problem = "Raja " + (turn == 'w' ? "hitam" : "putih") + " sedang diskak, jadi bukan giliran " + (turn == 'w' ? "Putih" : "Hitam") + ". Ubah tombol Giliran.";
            }
        }

        String castle = "" + (cK ? "K" : "") + (cQ ? "Q" : "") + (ck ? "k" : "") + (cq ? "q" : "");
        if (castle.isEmpty()) castle = "-";
        return placement + " " + turn + " " + castle + " " + ep + " 0 1";
    }

    private static String sanity(char[] b) {
        int[] n = new int[128]; int wk = -1, bk = -1;
        for (int i = 0; i < 64; i++) { if (b[i] != ' ') n[b[i]]++; if (b[i] == 'K') wk = i; if (b[i] == 'k') bk = i; }
        if (wk < 0 || bk < 0) return "Raja tidak lengkap.";
        if (Math.abs(wk / 8 - bk / 8) <= 1 && Math.abs(wk % 8 - bk % 8) <= 1) return "Dua raja bersebelahan (pembacaan keliru).";
        int wt = 0, bt = 0; for (char c : "KQRBNP".toCharArray()) wt += n[c]; for (char c : "kqrbnp".toCharArray()) bt += n[c];
        if (wt > 16 || bt > 16 || n['P'] > 8 || n['p'] > 8) return "Jumlah bidak tidak masuk akal (pembacaan keliru).";
        return null;
    }

    /** Apakah raja putih/hitam sedang diserang. b: urutan FEN (a8..h1). */
    static boolean kingAttacked(char[] b, boolean white) {
        char king = white ? 'K' : 'k'; int ki = -1;
        for (int i = 0; i < 64; i++) if (b[i] == king) ki = i;
        if (ki < 0) return false;
        int r = ki / 8, c = ki % 8;
        char P = white ? 'p' : 'P', N = white ? 'n' : 'N', B = white ? 'b' : 'B', R = white ? 'r' : 'R', Q = white ? 'q' : 'Q', K = white ? 'k' : 'K';
        int pr = white ? r - 1 : r + 1;                       // pion lawan menyerang dari baris ini
        for (int dc = -1; dc <= 1; dc += 2) if (pr >= 0 && pr < 8 && c + dc >= 0 && c + dc < 8 && b[pr * 8 + c + dc] == P) return true;
        int[][] kn = {{1, 2}, {2, 1}, {-1, 2}, {-2, 1}, {1, -2}, {2, -1}, {-1, -2}, {-2, -1}};
        for (int[] d : kn) { int rr = r + d[0], cc = c + d[1]; if (rr >= 0 && rr < 8 && cc >= 0 && cc < 8 && b[rr * 8 + cc] == N) return true; }
        for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) {
            if (dr == 0 && dc == 0) continue;
            int rr = r + dr, cc = c + dc;
            if (rr >= 0 && rr < 8 && cc >= 0 && cc < 8 && b[rr * 8 + cc] == K) return true;
            boolean diag = dr != 0 && dc != 0;
            for (rr = r + dr, cc = c + dc; rr >= 0 && rr < 8 && cc >= 0 && cc < 8; rr += dr, cc += dc) {
                char x = b[rr * 8 + cc];
                if (x == ' ') continue;
                if (x == Q || (diag ? x == B : x == R)) return true;
                break;
            }
        }
        return false;
    }
}
