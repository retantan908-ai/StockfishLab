package com.retan.stockfishlab;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;

/**
 * Activity transparan yang hanya meminta izin tangkap layar (dialog sistem),
 * lalu meneruskan hasilnya ke FloatingAnalysisService.
 */
public class ScreenCaptureActivity extends Activity {
    private static final int REQ = 811;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) return;   // dialog sudah tampil sebelum activity dibuat ulang
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ);
        } catch (Exception e) {
            deliver(RESULT_CANCELED, null);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ) deliver(resultCode, data);
    }

    private void deliver(int resultCode, Intent data) {
        Intent i = new Intent(this, FloatingAnalysisService.class);
        i.setAction(FloatingAnalysisService.ACTION_PROJECTION);
        i.putExtra(FloatingAnalysisService.EXTRA_CODE, resultCode);
        if (data != null) i.putExtra(FloatingAnalysisService.EXTRA_DATA, data);
        try { startService(i); } catch (Exception ignored) { }
        finish();
    }
}
